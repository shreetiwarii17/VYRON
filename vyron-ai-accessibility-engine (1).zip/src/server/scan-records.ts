import type { ScanRow } from "@/db/schema";
import type { ScanRecord } from "@/lib/accessibility/types";

export function serializeScan(row: ScanRow): ScanRecord {
  return {
    id: row.id,
    target: row.target,
    mode: row.mode,
    title: row.title,
    source: row.source,
    issues: row.issues,
    initialScore: row.initialScore,
    score: row.score,
    resolvedIds: row.resolvedIds,
    durationMs: row.durationMs,
    notice: row.notice,
    isSimulated: row.isSimulated,
    passedRules: row.passedRules,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}
