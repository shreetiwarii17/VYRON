import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { scans } from "@/db/schema";
import { calculateScore } from "@/lib/accessibility/types";
import { serializeScan } from "@/server/scan-records";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(_request: Request, context: RouteContext) {
  try {
    const { id } = await context.params;
    const [row] = await db.select().from(scans).where(eq(scans.id, id)).limit(1);
    if (!row) return NextResponse.json({ error: "Scan not found." }, { status: 404 });
    return NextResponse.json({ scan: serializeScan(row) });
  } catch (error) {
    console.error("Unable to load scan", error);
    return NextResponse.json({ error: "Unable to load this scan." }, { status: 500 });
  }
}

export async function PATCH(request: Request, context: RouteContext) {
  try {
    const { id } = await context.params;
    const body = (await request.json()) as { resolvedIds?: unknown };
    if (!Array.isArray(body.resolvedIds) || !body.resolvedIds.every((value) => typeof value === "string")) {
      return NextResponse.json({ error: "resolvedIds must be a string array." }, { status: 400 });
    }
    const [existing] = await db.select().from(scans).where(eq(scans.id, id)).limit(1);
    if (!existing) return NextResponse.json({ error: "Scan not found." }, { status: 404 });
    const validIds = new Set(existing.issues.map((issue) => issue.id));
    const resolvedIds = Array.from(new Set(body.resolvedIds.filter((value) => validIds.has(value))));
    const [row] = await db
      .update(scans)
      .set({
        resolvedIds,
        score: calculateScore(existing.issues, resolvedIds),
        updatedAt: new Date(),
      })
      .where(eq(scans.id, id))
      .returning();
    return NextResponse.json({ scan: serializeScan(row) });
  } catch (error) {
    console.error("Unable to update scan", error);
    return NextResponse.json({ error: "Unable to save resolution state." }, { status: 500 });
  }
}
