import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { scans } from "@/db/schema";
import { getDemoWorld } from "@/lib/demo-worlds";
import { auditSource, createSimulatedSource } from "@/lib/accessibility/engine";
import type { ScanMode, ScanRequest } from "@/lib/accessibility/types";
import { serializeScan } from "@/server/scan-records";

export const dynamic = "force-dynamic";

function publicHttpUrl(rawUrl: string) {
  const url = new URL(rawUrl);
  if (!["http:", "https:"].includes(url.protocol)) throw new Error("Only HTTP(S) URLs are supported.");
  const host = url.hostname.toLowerCase();
  const privateHost =
    host === "localhost" ||
    host === "::1" ||
    host.startsWith("127.") ||
    host.startsWith("10.") ||
    host.startsWith("192.168.") ||
    host.startsWith("169.254.") ||
    /^172\.(1[6-9]|2\d|3[01])\./.test(host);
  if (privateHost) throw new Error("Private and local network addresses cannot be scanned.");
  return url;
}

function titleFromSource(source: string, fallback: string) {
  const title = /<title\b[^>]*>([\s\S]*?)<\/title>/i.exec(source)?.[1]
    ?.replace(/<[^>]+>/g, "")
    .replace(/\s+/g, " ")
    .trim();
  return title?.slice(0, 140) || fallback;
}

export async function GET() {
  try {
    const rows = await db.select().from(scans).orderBy(desc(scans.createdAt)).limit(12);
    return NextResponse.json({ scans: rows.map(serializeScan) });
  } catch (error) {
    console.error("Unable to list scans", error);
    return NextResponse.json({ error: "Scan history is temporarily unavailable." }, { status: 500 });
  }
}

export async function POST(request: Request) {
  const startedAt = Date.now();
  try {
    const body = (await request.json()) as ScanRequest;
    const mode = body.mode;
    if (!["demo", "url", "code"].includes(mode)) {
      return NextResponse.json({ error: "Choose a valid scan source." }, { status: 400 });
    }

    let source = "";
    let target = "";
    let title = "Accessibility audit";
    let notice: string | null = null;
    let isSimulated = false;

    if (mode === "demo") {
      const world = getDemoWorld(body.demoId ?? "");
      if (!world) return NextResponse.json({ error: "That Demo World does not exist." }, { status: 400 });
      source = world.source;
      target = world.url;
      title = world.name;
    } else if (mode === "code") {
      source = body.code?.trim() ?? "";
      if (source.length < 20) {
        return NextResponse.json({ error: "Paste at least a small HTML fragment to audit." }, { status: 400 });
      }
      if (source.length > 600_000) {
        return NextResponse.json({ error: "Source is too large. Paste up to 600 KB of HTML." }, { status: 400 });
      }
      target = "Pasted HTML";
      title = titleFromSource(source, "Pasted source audit");
    } else {
      let url: URL;
      try {
        url = publicHttpUrl(body.url?.trim() ?? "");
      } catch (error) {
        return NextResponse.json(
          { error: error instanceof Error ? error.message : "Enter a valid public URL." },
          { status: 400 },
        );
      }
      target = url.toString();
      title = url.hostname;
      try {
        const response = await fetch(url, {
          cache: "no-store",
          redirect: "follow",
          signal: AbortSignal.timeout(7000),
          headers: {
            "user-agent": "VYRON-Accessibility-Audit/1.0 (+https://vyron.local)",
            accept: "text/html,application/xhtml+xml",
          },
        });
        if (!response.ok) throw new Error(`Origin responded ${response.status}`);
        const contentType = response.headers.get("content-type") ?? "";
        if (contentType && !/text\/html|application\/xhtml\+xml/i.test(contentType)) {
          throw new Error("URL did not return HTML");
        }
        source = (await response.text()).slice(0, 600_000);
        if (source.length < 20) throw new Error("Origin returned an empty document");
        title = titleFromSource(source, url.hostname);
      } catch (error) {
        console.warn("Live URL retrieval failed; using labeled simulation", error);
        source = createSimulatedSource(url.toString());
        isSimulated = true;
        title = `${url.hostname} · simulated snapshot`;
        notice = "Live retrieval was unavailable because of network, robots, or response policy. VYRON audited a labeled local simulation instead; paste the actual HTML for a source-accurate result.";
      }
    }

    const audited = auditSource(source, title);
    const durationMs = Date.now() - startedAt;
    const [row] = await db
      .insert(scans)
      .values({
        target,
        mode: mode as ScanMode,
        title,
        source,
        issues: audited.issues,
        initialScore: audited.score,
        score: audited.score,
        resolvedIds: [],
        durationMs,
        notice,
        isSimulated,
        passedRules: audited.passedRules,
      })
      .returning();

    return NextResponse.json({ scan: serializeScan(row) }, { status: 201 });
  } catch (error) {
    console.error("Unable to create scan", error);
    return NextResponse.json(
      { error: "The audit could not be completed. Check the source and try again." },
      { status: 500 },
    );
  }
}
