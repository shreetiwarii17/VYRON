import { VyronApp } from "@/components/vyron-app";

export default function HomePage() {
  return <VyronApp />;
}
