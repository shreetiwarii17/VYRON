import { sql } from "drizzle-orm";
import {
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uuid,
  varchar,
  boolean,
} from "drizzle-orm/pg-core";
import type {
  AccessibilityIssue,
  RuleId,
  ScanMode,
} from "@/lib/accessibility/types";

export const scans = pgTable("scans", {
  id: uuid("id").primaryKey().defaultRandom(),
  target: text("target").notNull(),
  mode: varchar("mode", { length: 16 }).$type<ScanMode>().notNull(),
  title: text("title").notNull(),
  source: text("source").notNull(),
  issues: jsonb("issues").$type<AccessibilityIssue[]>().notNull(),
  initialScore: integer("initial_score").notNull(),
  score: integer("score").notNull(),
  resolvedIds: jsonb("resolved_ids").$type<string[]>().notNull().default([]),
  durationMs: integer("duration_ms").notNull().default(0),
  notice: text("notice"),
  isSimulated: boolean("is_simulated").notNull().default(false),
  passedRules: jsonb("passed_rules").$type<RuleId[]>().notNull().default([]),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type ScanRow = typeof scans.$inferSelect;

export const databaseHealth = sql`select 1`;
