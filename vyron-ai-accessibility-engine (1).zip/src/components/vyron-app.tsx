"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { AlertCircle, CheckCircle2, LoaderCircle } from "lucide-react";
import type { Atmosphere } from "@/lib/atmospheres";
import type { AccessibilityIssue, ReportLanguage, ScanRecord, ScanRequest, ScanResponse } from "@/lib/accessibility/types";
import { getDemoWorld } from "@/lib/demo-worlds";
import { downloadScanReport } from "@/lib/accessibility/report-pdf";
import { TopBar } from "@/components/top-bar";
import { CommandCenter } from "@/components/command-center";
import { ScanningSequence } from "@/components/scanning-sequence";
import { Dashboard } from "@/components/dashboard";
import { DiffModal } from "@/components/diff-modal";
import { ReportModal } from "@/components/report-modal";
import { HistoryDrawer } from "@/components/history-drawer";

const delay = (milliseconds: number) => new Promise((resolve) => window.setTimeout(resolve, milliseconds));

type Toast = { id: number; message: string; tone: "success" | "error" | "info" };

export function VyronApp() {
  const [phase, setPhase] = useState<"home" | "scanning" | "results">("home");
  const [scan, setScan] = useState<ScanRecord | null>(null);
  const [history, setHistory] = useState<ScanRecord[]>([]);
  const [historyLoading, setHistoryLoading] = useState(true);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [selectedIssue, setSelectedIssue] = useState<AccessibilityIssue | null>(null);
  const [atmosphere, setAtmosphere] = useState<Atmosphere>("cosmic");
  const [language, setLanguage] = useState<ReportLanguage>("en");
  const [settingsLoaded, setSettingsLoaded] = useState(false);
  const [pending, setPending] = useState<{ target: string; source?: string }>({ target: "Preparing document" });
  const [toast, setToast] = useState<Toast | null>(null);
  const [pdfBusy, setPdfBusy] = useState(false);
  const requestToken = useRef(0);
  const restoreStarted = useRef(false);
  const reduceMotion = useReducedMotion();

  const showToast = useCallback((message: string, tone: Toast["tone"] = "success") => {
    setToast({ id: Date.now(), message, tone });
  }, []);

  const loadHistory = useCallback(async () => {
    try {
      const response = await fetch("/api/scans", { cache: "no-store" });
      if (!response.ok) throw new Error("History unavailable");
      const data = (await response.json()) as { scans: ScanRecord[] };
      setHistory(data.scans);
    } catch {
      // History is supplemental; a failed list should not block a new audit.
    } finally {
      setHistoryLoading(false);
    }
  }, []);

  useEffect(() => {
    try {
      const savedAtmosphere = window.localStorage.getItem("vyron-atmosphere") as Atmosphere | null;
      const savedLanguage = window.localStorage.getItem("vyron-report-language") as ReportLanguage | null;
      if (savedAtmosphere && ["cosmic", "sunset", "daylight", "cyber"].includes(savedAtmosphere)) setAtmosphere(savedAtmosphere);
      if (savedLanguage && ["en", "hi"].includes(savedLanguage)) setLanguage(savedLanguage);
    } catch {
      // The application also works when storage is restricted.
    }
    setSettingsLoaded(true);
    void loadHistory();

    if (restoreStarted.current) return;
    restoreStarted.current = true;
    let lastId: string | null = null;
    try { lastId = window.localStorage.getItem("vyron-last-scan"); } catch { /* restoration is optional */ }
    if (!lastId) return;
    void fetch(`/api/scans/${lastId}`, { cache: "no-store" })
      .then(async (response) => {
        if (!response.ok) return;
        const data = (await response.json()) as ScanResponse;
        if (requestToken.current !== 0) return;
        setScan(data.scan);
        setPhase("results");
      })
      .catch(() => {
        // Users can still begin a fresh scan if restoration fails.
      });
  }, [loadHistory]);

  useEffect(() => {
    if (!settingsLoaded) return;
    try {
      window.localStorage.setItem("vyron-atmosphere", atmosphere);
      window.localStorage.setItem("vyron-report-language", language);
    } catch {
      // Non-persistent mode remains fully functional.
    }
  }, [atmosphere, language, settingsLoaded]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 3600);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const startScan = useCallback(async (request: ScanRequest, streamSource?: string) => {
    const token = ++requestToken.current;
    const world = request.mode === "demo" ? getDemoWorld(request.demoId ?? "") : null;
    const target = world?.url ?? request.url ?? "Pasted HTML source";
    setPending({ target, source: streamSource });
    setSelectedIssue(null);
    setReportOpen(false);
    setHistoryOpen(false);
    setPhase("scanning");
    const minimumSequence = delay(reduceMotion ? 150 : 3300);

    try {
      const [response] = await Promise.all([
        fetch("/api/scans", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(request),
        }),
        minimumSequence,
      ]);
      const data = (await response.json()) as ScanResponse & { error?: string };
      if (!response.ok) throw new Error(data.error ?? "The audit could not be completed.");
      if (token !== requestToken.current) return;
      setScan(data.scan);
      setPhase("results");
      setHistory((items) => [data.scan, ...items.filter((item) => item.id !== data.scan.id)].slice(0, 12));
      try { window.localStorage.setItem("vyron-last-scan", data.scan.id); } catch { /* storage is optional */ }
      showToast(data.scan.isSimulated ? "Simulated audit ready. Live retrieval was unavailable." : `Audit complete: ${data.scan.issues.length} findings mapped to source.`, data.scan.isSimulated ? "info" : "success");
    } catch (error) {
      if (token !== requestToken.current) return;
      setPhase("home");
      showToast(error instanceof Error ? error.message : "The audit could not be completed.", "error");
    }
  }, [reduceMotion, showToast]);

  const goHome = useCallback(() => {
    requestToken.current += 1;
    setPhase("home");
    setSelectedIssue(null);
    setReportOpen(false);
    setHistoryOpen(false);
  }, []);

  const rescan = useCallback(() => {
    if (!scan) return;
    if (scan.mode === "demo") {
      const worldId = scan.target.split("/").pop();
      const world = getDemoWorld(worldId === "aster-and-row" ? "aster-row" : worldId ?? "");
      // IDs and slugs differ only for Aster & Row; match by URL for every other world.
      const matched = world ?? (scan.target.includes("aster-and-row") ? getDemoWorld("aster-row") : undefined);
      if (matched) return void startScan({ mode: "demo", demoId: matched.id }, matched.source);
    }
    if (scan.mode === "code") return void startScan({ mode: "code", code: scan.source }, scan.source);
    return void startScan({ mode: "url", url: scan.target });
  }, [scan, startScan]);

  const updateResolved = useCallback(async (issue: AccessibilityIssue, shouldResolve: boolean) => {
    if (!scan) return;
    const resolvedIds = shouldResolve
      ? Array.from(new Set([...scan.resolvedIds, issue.id]))
      : scan.resolvedIds.filter((id) => id !== issue.id);
    try {
      const response = await fetch(`/api/scans/${scan.id}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ resolvedIds }),
      });
      const data = (await response.json()) as ScanResponse & { error?: string };
      if (!response.ok) throw new Error(data.error ?? "Unable to save this resolution.");
      setScan(data.scan);
      setHistory((items) => items.map((item) => item.id === data.scan.id ? data.scan : item));
      if (!shouldResolve) showToast("Resolution undone. The original issue is open again.", "info");
    } catch (error) {
      showToast(error instanceof Error ? error.message : "Unable to save this resolution.", "error");
      throw error;
    }
  }, [scan, showToast]);

  const openHistoryScan = (nextScan: ScanRecord) => {
    requestToken.current += 1;
    setScan(nextScan);
    setPhase("results");
    setHistoryOpen(false);
    setSelectedIssue(null);
    try { window.localStorage.setItem("vyron-last-scan", nextScan.id); } catch { /* storage is optional */ }
  };

  const downloadPdf = useCallback(async () => {
    if (!scan || pdfBusy) return;
    setPdfBusy(true);
    showToast(`Preparing your ${language === "hi" ? "Hindi" : "English"} PDF report…`, "info");
    try {
      await downloadScanReport(scan, language);
      showToast("Full PDF report downloaded.");
    } catch (error) {
      showToast(error instanceof Error ? `PDF export failed: ${error.message}` : "PDF export failed.", "error");
    } finally {
      setPdfBusy(false);
    }
  }, [scan, language, pdfBusy, showToast]);

  return (
    <div className="vyron-app" data-atmosphere={atmosphere}>
      <TopBar atmosphere={atmosphere} onAtmosphereChange={setAtmosphere} phase={phase} historyCount={history.length} onHome={goHome} onNewScan={goHome} onHistory={() => setHistoryOpen(true)} />

      <AnimatePresence mode="wait" initial={false}>
        {phase === "home" && <motion.div key="home" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, y: reduceMotion ? 0 : -12 }} transition={{ duration: 0.28 }}><CommandCenter onScan={startScan} /></motion.div>}
        {phase === "scanning" && <motion.div key="scanning" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, scale: reduceMotion ? 1 : 0.99 }} transition={{ duration: 0.28 }}><ScanningSequence target={pending.target} source={pending.source} /></motion.div>}
        {phase === "results" && scan && <motion.div key={`results-${scan.id}`} initial={{ opacity: 0, y: reduceMotion ? 0 : 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.35 }}><Dashboard scan={scan} language={language} onLanguageChange={setLanguage} onRescan={rescan} onResolve={setSelectedIssue} onReport={() => setReportOpen(true)} onDownloadPdf={() => void downloadPdf()} onToast={(message) => showToast(message)} /></motion.div>}
      </AnimatePresence>

      <AnimatePresence>
        {selectedIssue && scan && <DiffModal key={selectedIssue.id} issue={selectedIssue} scan={scan} language={language} onClose={() => setSelectedIssue(null)} onApply={(issue) => updateResolved(issue, true)} onUndo={(issue) => updateResolved(issue, false)} onDownloadPdf={() => void downloadPdf()} onToast={(message) => showToast(message)} />}
      </AnimatePresence>
      <AnimatePresence>
        {reportOpen && scan && <ReportModal scan={scan} language={language} onLanguageChange={setLanguage} onClose={() => setReportOpen(false)} onDownloadPdf={() => void downloadPdf()} onToast={(message) => showToast(message)} />}
      </AnimatePresence>
      <AnimatePresence>
        {historyOpen && <HistoryDrawer scans={history} currentId={scan?.id} loading={historyLoading} onClose={() => setHistoryOpen(false)} onSelect={openHistoryScan} onNewScan={goHome} />}
      </AnimatePresence>

      <AnimatePresence>
        {toast && <motion.div key={toast.id} initial={{ opacity: 0, y: 18, scale: 0.96 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 10, scale: 0.98 }} className="glass fixed bottom-5 left-1/2 z-[100] flex w-[calc(100%-32px)] max-w-md -translate-x-1/2 items-center gap-3 rounded-xl px-4 py-3 shadow-2xl" role="status">
          <span className={`grid h-7 w-7 shrink-0 place-items-center rounded-full ${toast.tone === "error" ? "bg-red-400/10 text-red-400" : toast.tone === "info" ? "bg-[var(--accent-soft)] text-[var(--accent-bright)]" : "bg-emerald-400/10 text-emerald-400"}`}>{toast.tone === "info" && pdfBusy ? <LoaderCircle size={14} className="animate-spin" /> : toast.tone === "error" ? <AlertCircle size={14} /> : <CheckCircle2 size={14} />}</span>
          <p className="text-[10px] leading-relaxed text-soft">{toast.message}</p>
        </motion.div>}
      </AnimatePresence>
    </div>
  );
}
