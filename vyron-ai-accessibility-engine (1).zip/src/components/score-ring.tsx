"use client";

import { useEffect, useState } from "react";
import { animate, motion, useReducedMotion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";

interface ScoreRingProps {
  score: number;
  initialScore: number;
  size?: number;
}

export function ScoreRing({ score, initialScore, size = 190 }: ScoreRingProps) {
  const [displayScore, setDisplayScore] = useState(initialScore);
  const reduceMotion = useReducedMotion();
  const stroke = 8;
  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const color = score >= 85 ? "#34d399" : score >= 60 ? "var(--accent)" : "#f5a524";
  const track = score >= 85 ? "rgba(52,211,153,.12)" : score >= 60 ? "var(--accent-soft)" : "rgba(245,165,36,.12)";
  const improvement = score - initialScore;

  useEffect(() => {
    if (reduceMotion) {
      setDisplayScore(score);
      return;
    }
    const controls = animate(displayScore, score, {
      duration: 0.9,
      ease: [0.22, 1, 0.36, 1],
      onUpdate: (value) => setDisplayScore(Math.round(value)),
    });
    return () => controls.stop();
    // displayScore is intentionally captured as the animation's starting value.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [score, reduceMotion]);

  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <div className="absolute inset-5 rounded-full opacity-30 blur-2xl" style={{ background: color }} />
      <motion.svg viewBox="0 0 160 160" className="relative h-full w-full -rotate-90" initial={reduceMotion ? false : { opacity: 0, rotate: -110 }} animate={{ opacity: 1, rotate: -90 }} transition={{ duration: 0.8 }}>
        <circle cx="80" cy="80" r={radius} fill="none" stroke={track} strokeWidth={stroke} />
        <circle cx="80" cy="80" r="60" fill="none" stroke="var(--border)" strokeWidth="1" strokeDasharray="1 7" />
        <motion.circle
          cx="80"
          cy="80"
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: circumference - (score / 100) * circumference }}
          transition={{ duration: reduceMotion ? 0 : 1.1, ease: [0.22, 1, 0.36, 1] }}
          style={{ filter: `drop-shadow(0 0 7px ${color})` }}
        />
      </motion.svg>
      <div className="absolute inset-0 flex rotate-0 flex-col items-center justify-center">
        <span className="mb-1 text-[9px] font-semibold uppercase tracking-[0.16em] text-muted">Accessibility</span>
        <div className="flex items-start font-semibold tracking-[-0.07em]" style={{ color }}><span className="text-[52px] leading-none">{displayScore}</span><span className="ml-1 mt-1 text-xs font-medium tracking-normal text-muted">/100</span></div>
        {improvement > 0 ? (
          <motion.span initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className="mt-2 flex items-center gap-1 rounded-full bg-emerald-400/10 px-2 py-1 text-[9px] font-semibold text-emerald-400"><ArrowUpRight size={10} /> +{improvement} points</motion.span>
        ) : (
          <span className="mt-2 text-[9px] font-medium text-muted">{score >= 85 ? "Excellent foundation" : score >= 60 ? "Making progress" : "Needs attention"}</span>
        )}
      </div>
    </div>
  );
}
