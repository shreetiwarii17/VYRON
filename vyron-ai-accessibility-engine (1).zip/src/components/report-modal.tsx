"use client";

import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Check,
  CheckCircle2,
  ChevronDown,
  Clipboard,
  Download,
  FileCode2,
  FileDown,
  FileText,
  Globe2,
  Languages,
  ShieldCheck,
  X,
} from "lucide-react";
import type { ReportLanguage, ScanRecord } from "@/lib/accessibility/types";
import { applyResolvedFixes, createUnifiedPatch } from "@/lib/accessibility/patch";
import { copyToClipboard, downloadTextFile, safeFilename } from "@/lib/client-utils";
import { ISSUE_TITLE_HI, REPORT_COPY, reportPriority, reportSummary } from "@/lib/accessibility/reporting";

interface ReportModalProps {
  scan: ScanRecord;
  language: ReportLanguage;
  onLanguageChange: (language: ReportLanguage) => void;
  onClose: () => void;
  onDownloadPdf: () => void;
  onToast: (message: string) => void;
}

export function ReportModal({ scan, language, onLanguageChange, onClose, onDownloadPdf, onToast }: ReportModalProps) {
  const [expanded, setExpanded] = useState<string | null>(scan.issues[0]?.id ?? null);
  const [copied, setCopied] = useState(false);
  const copy = REPORT_COPY[language];
  const patch = useMemo(() => createUnifiedPatch(scan.source, scan.issues, scan.resolvedIds), [scan]);

  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const keydown = (event: KeyboardEvent) => event.key === "Escape" && onClose();
    document.addEventListener("keydown", keydown);
    return () => {
      document.body.style.overflow = previous;
      document.removeEventListener("keydown", keydown);
    };
  }, [onClose]);

  const copyPatch = async () => {
    await copyToClipboard(patch);
    setCopied(true);
    onToast("Unified patch copied to clipboard.");
    window.setTimeout(() => setCopied(false), 1800);
  };

  return (
    <motion.div className="fixed inset-0 z-[75] flex items-center justify-center p-0 sm:p-5" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <button className="absolute inset-0 bg-[#020610]/80 backdrop-blur-md" onClick={onClose} aria-label="Close report" />
      <motion.section role="dialog" aria-modal="true" aria-label={copy.report} initial={{ opacity: 0, x: 30, scale: 0.985 }} animate={{ opacity: 1, x: 0, scale: 1 }} exit={{ opacity: 0, x: 20 }} transition={{ type: "spring", stiffness: 350, damping: 34 }} className="relative ml-auto flex h-full max-h-[950px] w-full max-w-[980px] flex-col overflow-hidden border-[var(--border)] bg-[var(--panel-solid)] shadow-2xl sm:rounded-2xl sm:border">
        <header className="flex min-h-[70px] shrink-0 items-center gap-3 border-b border-[var(--border)] px-4 sm:px-6">
          <span className="grid h-9 w-9 place-items-center rounded-[10px] border border-[var(--accent-line)] bg-[var(--accent-soft)] text-[var(--accent-bright)]"><FileText size={17} /></span>
          <div className="min-w-0 flex-1"><h2 className="truncate text-sm font-semibold tracking-[-0.02em]">{copy.report}</h2><p className="mt-1 truncate text-[9px] text-muted">{scan.title} · {new Date(scan.createdAt).toLocaleDateString(language === "hi" ? "hi-IN" : "en-IN", { day: "numeric", month: "short", year: "numeric" })}</p></div>
          <div className="flex rounded-lg border border-[var(--border)] bg-[var(--panel)] p-0.5" aria-label="Report language"><button onClick={() => onLanguageChange("en")} className={`rounded-md px-2.5 py-1.5 text-[9px] font-semibold ${language === "en" ? "bg-[var(--accent-soft)] text-[var(--accent-bright)]" : "text-muted"}`}>EN</button><button onClick={() => onLanguageChange("hi")} lang="hi" className={`rounded-md px-2.5 py-1.5 text-[10px] font-semibold ${language === "hi" ? "bg-[var(--accent-soft)] text-[var(--accent-bright)]" : "text-muted"}`}>हिन्दी</button></div>
          <button onClick={onClose} autoFocus className="soft-button grid h-9 w-9 place-items-center rounded-lg" aria-label="Close report"><X size={16} /></button>
        </header>

        <div className="custom-scroll min-h-0 flex-1 overflow-y-auto p-4 sm:p-6">
          <section className="overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--panel)]">
            <div className="grid grid-cols-3 divide-x divide-[var(--border)] border-b border-[var(--border)]">
              {[
                { label: language === "hi" ? "अभी का score" : "Current score", value: `${scan.score}/100`, color: scan.score >= 85 ? "#34d399" : "var(--accent-bright)" },
                { label: language === "hi" ? "समाधान" : "Resolved", value: `${scan.resolvedIds.length}/${scan.issues.length}`, color: "#34d399" },
                { label: language === "hi" ? "शुरुआती score" : "Initial score", value: `${scan.initialScore}/100`, color: "var(--muted)" },
              ].map((metric) => <div key={metric.label} className="p-3 sm:p-4"><p className="text-[8px] font-semibold uppercase tracking-[0.12em] text-muted">{metric.label}</p><p className="mt-2 font-mono text-lg font-semibold tracking-[-0.04em] sm:text-2xl" style={{ color: metric.color }}>{metric.value}</p></div>)}
            </div>
            <div className="grid gap-5 p-4 sm:grid-cols-2 sm:p-5">
              <div><h3 className="mb-2 flex items-center gap-2 text-[10px] font-semibold"><Globe2 size={12} style={{ color: "var(--accent)" }} />{copy.summary}</h3><p lang={language === "hi" ? "hi" : "en"} className="text-[11px] leading-[1.85] text-muted">{reportSummary(scan, language)}</p></div>
              <div><h3 className="mb-2 flex items-center gap-2 text-[10px] font-semibold"><ShieldCheck size={12} className="text-amber-400" />{copy.priority}</h3><p lang={language === "hi" ? "hi" : "en"} className="text-[11px] leading-[1.85] text-muted">{reportPriority(scan, language)}</p></div>
            </div>
          </section>

          {scan.notice && <div className="mt-4 rounded-xl border border-amber-400/20 bg-amber-400/[.06] p-4 text-[10px] leading-relaxed text-amber-300"><strong className="mb-1 block text-[9px] uppercase tracking-wider">Retrieval transparency</strong>{scan.notice}</div>}

          <div className="mb-3 mt-7 flex items-center justify-between"><h3 className="text-xs font-semibold">{copy.findings}</h3><span className="flex items-center gap-1.5 text-[9px] text-muted"><Languages size={11} /> {language === "hi" ? "हिन्दी विवरण" : "English details"}</span></div>
          <div className="space-y-2">
            {scan.issues.map((issue, index) => {
              const isOpen = expanded === issue.id;
              const resolved = scan.resolvedIds.includes(issue.id);
              return (
                <article key={issue.id} className={`overflow-hidden rounded-xl border ${isOpen ? "border-[var(--border-strong)]" : "border-[var(--border)]"}`}>
                  <button onClick={() => setExpanded(isOpen ? null : issue.id)} className="flex w-full items-center gap-3 bg-[var(--panel)] p-3 text-left sm:p-4" aria-expanded={isOpen}>
                    <span className={`grid h-7 w-7 shrink-0 place-items-center rounded-lg font-mono text-[9px] ${resolved ? "bg-emerald-400/10 text-emerald-400" : "bg-amber-400/10 text-amber-400"}`}>{resolved ? <CheckCircle2 size={13} /> : String(index + 1).padStart(2, "0")}</span>
                    <span className="min-w-0 flex-1"><span lang={language === "hi" ? "hi" : "en"} className="block text-[11px] font-medium text-soft">{language === "hi" ? ISSUE_TITLE_HI[issue.rule] : issue.title}</span><span className="mt-1 block text-[8px] uppercase tracking-wider text-muted">WCAG {issue.wcag} · line {issue.line} · {resolved ? copy.resolved : copy.open}</span></span>
                    <ChevronDown size={14} className={`shrink-0 text-muted transition-transform ${isOpen ? "rotate-180" : ""}`} />
                  </button>
                  <AnimatePresence initial={false}>
                    {isOpen && <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden"><div className="border-t border-[var(--border)] p-4">
                      <p lang={language === "hi" ? "hi" : "en"} className="text-[11px] leading-[1.85] text-muted">{language === "hi" ? issue.explanationHi : issue.explanationEn}</p>
                      {issue.context && <p className="mt-3 font-mono text-[8px] leading-relaxed text-[var(--faint)]">{issue.context}</p>}
                      <div className="mt-4 grid gap-3 lg:grid-cols-2"><div className="code-window code-broken overflow-hidden rounded-lg border"><p className="border-b border-white/5 px-3 py-2 text-[8px] font-semibold uppercase tracking-wider text-red-300">{copy.before}</p><pre className="custom-scroll max-h-44 overflow-auto whitespace-pre-wrap break-words p-3 font-mono text-[9px] leading-relaxed text-slate-400">{issue.snippet}</pre></div><div className="code-window code-fixed overflow-hidden rounded-lg border"><p className="border-b border-white/5 px-3 py-2 text-[8px] font-semibold uppercase tracking-wider text-emerald-300">{copy.after}</p><pre className="custom-scroll max-h-44 overflow-auto whitespace-pre-wrap break-words p-3 font-mono text-[9px] leading-relaxed text-slate-400">{issue.fixedSnippet}</pre></div></div>
                    </div></motion.div>}
                  </AnimatePresence>
                </article>
              );
            })}
          </div>

          <div className="mt-6 rounded-xl border border-[var(--border)] p-4"><h3 className="text-[10px] font-semibold">{copy.conformance}</h3><p lang={language === "hi" ? "hi" : "en"} className="mt-2 text-[10px] leading-[1.8] text-muted">{copy.conformanceText}</p></div>
        </div>

        <footer className="flex shrink-0 flex-wrap items-center gap-2 border-t border-[var(--border)] bg-[var(--panel)] px-4 py-3 sm:px-6">
          <p className="mr-auto hidden text-[9px] text-muted md:block">{copy.generated}</p>
          <button onClick={copyPatch} disabled={!scan.resolvedIds.length} className="soft-button flex items-center gap-2 rounded-lg px-3 py-2.5 text-[10px] font-medium disabled:opacity-40" title={!scan.resolvedIds.length ? "Resolve an issue to create a patch" : "Copy unified diff"}>{copied ? <Check size={13} /> : <Clipboard size={13} />}{copied ? "Copied" : "Copy patch"}</button>
          <button onClick={() => { downloadTextFile(patch, `vyron-${safeFilename(scan.title)}.patch`, "text/x-diff"); onToast("Patch file downloaded."); }} disabled={!scan.resolvedIds.length} className="soft-button flex items-center gap-2 rounded-lg px-3 py-2.5 text-[10px] font-medium disabled:opacity-40"><Download size={13} />.patch</button>
          <button onClick={() => { const fixedSource = applyResolvedFixes(scan.source, scan.issues, scan.resolvedIds); downloadTextFile(fixedSource, `vyron-${safeFilename(scan.title)}-fixed.html`, "text/html"); onToast("Patched HTML downloaded."); }} disabled={!scan.resolvedIds.length} className="soft-button flex items-center gap-2 rounded-lg px-3 py-2.5 text-[10px] font-medium disabled:opacity-40"><FileCode2 size={13} />Fixed HTML</button>
          <button onClick={onDownloadPdf} className="ai-button flex items-center gap-2 rounded-lg px-4 py-2.5 text-[10px] font-semibold"><FileDown size={13} /> Download PDF</button>
        </footer>
      </motion.section>
    </motion.div>
  );
}
