"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft,
  Check,
  ChevronDown,
  Clock3,
  Layers3,
  Plus,
  ScanLine,
  Sparkles,
} from "lucide-react";
import { ATMOSPHERES, type Atmosphere } from "@/lib/atmospheres";

interface TopBarProps {
  atmosphere: Atmosphere;
  onAtmosphereChange: (atmosphere: Atmosphere) => void;
  phase: "home" | "scanning" | "results";
  historyCount: number;
  onHome: () => void;
  onNewScan: () => void;
  onHistory: () => void;
}

export function TopBar({
  atmosphere,
  onAtmosphereChange,
  phase,
  historyCount,
  onHome,
  onNewScan,
  onHistory,
}: TopBarProps) {
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const current = ATMOSPHERES.find((item) => item.id === atmosphere) ?? ATMOSPHERES[2];

  useEffect(() => {
    const close = (event: PointerEvent) => {
      if (!menuRef.current?.contains(event.target as Node)) setOpen(false);
    };
    const escape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.addEventListener("pointerdown", close);
    document.addEventListener("keydown", escape);
    return () => {
      document.removeEventListener("pointerdown", close);
      document.removeEventListener("keydown", escape);
    };
  }, []);

  const steps = ["Input", "Scan", "Resolve"];
  const activeStep = phase === "home" ? 0 : phase === "scanning" ? 1 : 2;

  return (
    <header
      className="sticky top-0 z-40 border-b backdrop-blur-2xl"
      style={{ borderColor: "var(--border)", background: "var(--header)" }}
    >
      <div className="mx-auto flex h-[72px] max-w-[1600px] items-center justify-between gap-3 px-4 sm:px-6 lg:px-8">
        <button onClick={onHome} className="group flex shrink-0 items-center gap-3 rounded-lg text-left" aria-label="VYRON home">
          <span className="relative grid h-8 w-8 place-items-center overflow-hidden rounded-[9px] border border-[var(--accent-line)] bg-[var(--accent-soft)]">
            <ScanLine size={17} style={{ color: "var(--accent-bright)" }} />
            <span className="scan-line absolute bottom-1 left-0 h-px w-full opacity-60" />
          </span>
          <span>
            <span className="vyron-logo block text-[22px] font-extrabold leading-none tracking-[-0.055em]">VYRON</span>
            <span className="mt-1 block text-[9px] font-medium uppercase tracking-[0.13em] text-muted">
              by Team <span lang="hi">कृत्रिम</span>
            </span>
          </span>
        </button>

        <div className="absolute left-1/2 hidden -translate-x-1/2 items-center gap-2 lg:flex" aria-label="Audit progress">
          {steps.map((step, index) => (
            <div key={step} className="flex items-center gap-2">
              <div className={`flex items-center gap-2 rounded-full px-2.5 py-1 text-[11px] font-medium transition-colors ${index === activeStep ? "bg-[var(--accent-soft)] text-[var(--accent-bright)]" : index < activeStep ? "text-soft" : "text-muted"}`}>
                <span className={`grid h-4 w-4 place-items-center rounded-full border text-[8px] ${index === activeStep ? "border-[var(--accent-line)]" : "border-[var(--border)]"}`}>
                  {index < activeStep ? <Check size={10} /> : index + 1}
                </span>
                {step}
              </div>
              {index < steps.length - 1 && <span className="h-px w-5 bg-[var(--border)]" />}
            </div>
          ))}
        </div>

        <div className="flex items-center gap-2">
          {phase === "results" && (
            <button onClick={onNewScan} className="soft-button hidden h-9 items-center gap-2 rounded-lg px-3 text-xs font-medium sm:flex">
              <Plus size={14} /> New scan
            </button>
          )}
          {phase === "scanning" && (
            <button onClick={onHome} className="soft-button hidden h-9 items-center gap-2 rounded-lg px-3 text-xs sm:flex">
              <ArrowLeft size={14} /> Cancel
            </button>
          )}
          <button onClick={onHistory} className="soft-button relative grid h-9 w-9 place-items-center rounded-lg" aria-label={`Open scan history, ${historyCount} scans`}>
            <Clock3 size={15} />
            {historyCount > 0 && <span className="absolute -right-1 -top-1 h-2 w-2 rounded-full" style={{ background: "var(--accent)" }} />}
          </button>
          <div className="relative" ref={menuRef}>
            <button
              onClick={() => setOpen((value) => !value)}
              className="soft-button flex h-9 items-center gap-2 rounded-lg px-2.5 text-xs font-medium"
              aria-expanded={open}
              aria-haspopup="dialog"
            >
              <span className="h-4 w-4 rounded-full border border-white/20 shadow-sm" style={{ background: current.swatch }} />
              <span className="hidden md:inline">{current.name}</span>
              <Layers3 size={13} className="md:hidden" />
              <ChevronDown size={12} className={`transition-transform ${open ? "rotate-180" : ""}`} />
            </button>
            <AnimatePresence>
              {open && (
                <motion.div
                  initial={{ opacity: 0, y: -8, scale: 0.97 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -6, scale: 0.98 }}
                  transition={{ duration: 0.18 }}
                  className="glass absolute right-0 top-12 w-[min(390px,calc(100vw-24px))] rounded-xl p-3 shadow-2xl"
                  role="dialog"
                  aria-label="Choose workspace atmosphere"
                >
                  <div className="mb-3 flex items-center justify-between px-1">
                    <div>
                      <p className="text-xs font-semibold">Workspace atmosphere</p>
                      <p className="mt-0.5 text-[10px] text-muted">Same engine. A different point of view.</p>
                    </div>
                    <Sparkles size={14} style={{ color: "var(--accent)" }} />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {ATMOSPHERES.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => {
                          onAtmosphereChange(item.id);
                          setOpen(false);
                        }}
                        className={`rounded-[10px] border p-2 text-left transition-all hover:-translate-y-0.5 ${atmosphere === item.id ? "border-[var(--accent-line)] bg-[var(--accent-soft)]" : "border-[var(--border)] hover:bg-[var(--panel-raised)]"}`}
                      >
                        <span className="relative mb-2 block h-10 overflow-hidden rounded-md border border-white/10" style={{ background: item.swatch }}>
                          <span className="absolute inset-x-2 bottom-2 h-1 rounded-full bg-white/25" />
                          {atmosphere === item.id && <span className="absolute right-1.5 top-1.5 grid h-4 w-4 place-items-center rounded-full bg-white text-slate-900"><Check size={10} strokeWidth={3} /></span>}
                        </span>
                        <span className="block text-[11px] font-semibold">{item.name}</span>
                        <span className="mt-1 block text-[9px] leading-relaxed text-muted">{item.description}</span>
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </header>
  );
}
