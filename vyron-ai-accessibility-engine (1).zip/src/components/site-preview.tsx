"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Eye, Globe2, Monitor, ScanLine } from "lucide-react";
import type { AccessibilityIssue, ScanMode } from "@/lib/accessibility/types";

function escapeXml(value: string) {
  return value.replace(/[<>&"']/g, (character) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", '"': "&quot;", "'": "&apos;" })[character] ?? character);
}

function imagePlaceholder(src: string) {
  const label = src.split("/").pop()?.replace(/\.[a-z0-9]+$/i, "").replace(/[-_]/g, " ") || "Page image";
  const hash = Array.from(src).reduce((total, character) => total + character.charCodeAt(0), 0);
  const hues = [[165, 197], [26, 348], [224, 262], [191, 157]][hash % 4];
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="900" height="560" viewBox="0 0 900 560"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="hsl(${hues[0]} 35% 72%)"/><stop offset="1" stop-color="hsl(${hues[1]} 32% 42%)"/></linearGradient></defs><rect width="900" height="560" fill="url(#g)"/><circle cx="700" cy="130" r="74" fill="white" opacity=".25"/><path d="M0 470L240 235l130 125 120-105 410 320H0z" fill="white" opacity=".16"/><path d="M0 510l290-205 150 140 125-90 335 205v20H0z" fill="#14231f" opacity=".18"/><text x="42" y="510" fill="white" opacity=".82" font-family="Arial,sans-serif" font-size="22" letter-spacing="2">${escapeXml(label.toUpperCase())}</text></svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

function preparePreview(source: string, issues: AccessibilityIssue[], target: string, mode: ScanMode, simulated: boolean) {
  // Mark original source positions before any transformation changes string length.
  let output = source;
  const positioned = issues
    .filter((issue) => /^<[a-z]/i.test(source.slice(issue.start, issue.start + 2)))
    .sort((a, b) => b.start - a.start);
  for (const issue of positioned) {
    const tag = /^<([a-z][\w-]*)/i.exec(output.slice(issue.start, issue.start + 40));
    if (!tag) continue;
    const insertAt = issue.start + tag[0].length;
    output = `${output.slice(0, insertAt)} data-vyron-${issue.id}=""${output.slice(insertAt)}`;
  }

  output = output
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, "")
    .replace(/<(?:iframe|object|embed)\b[^>]*>[\s\S]*?<\/(?:iframe|object|embed)>/gi, "")
    .replace(/\son[a-z]+\s*=\s*(["'])[\s\S]*?\1/gi, "")
    .replace(/javascript\s*:/gi, "about:blank#");

  if (mode === "demo" || simulated) {
    output = output.replace(/(<img\b[^>]*?\bsrc\s*=\s*)(["'])(.*?)\2/gi, (_match, prefix: string, quote: string, src: string) => {
      if (/^(?:data:|https?:\/\/)/i.test(src)) return `${prefix}${quote}${src}${quote}`;
      return `${prefix}${quote}${imagePlaceholder(src)}${quote}`;
    });
  } else if (mode === "url") {
    const base = `<base href="${target.replace(/"/g, "&quot;")}">`;
    output = /<head\b[^>]*>/i.test(output) ? output.replace(/<head\b[^>]*>/i, (match) => `${match}${base}`) : `${base}${output}`;
  }
  return output;
}

interface SitePreviewProps {
  source: string;
  issues: AccessibilityIssue[];
  activeIssue: AccessibilityIssue | null;
  resolvedIds: string[];
  target: string;
  mode: ScanMode;
  isSimulated: boolean;
  compact?: boolean;
}

export function SitePreview({ source, issues, activeIssue, resolvedIds, target, mode, isSimulated, compact = false }: SitePreviewProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [ready, setReady] = useState(0);
  const preview = useMemo(() => preparePreview(source, issues, target, mode, isSimulated), [source, issues, target, mode, isSimulated]);

  useEffect(() => {
    const document = iframeRef.current?.contentDocument;
    if (!document) return;
    document.querySelectorAll("[data-vyron-active]").forEach((element) => element.removeAttribute("data-vyron-active"));
    document.getElementById("vyron-preview-style")?.remove();
    const style = document.createElement("style");
    style.id = "vyron-preview-style";
    style.textContent = `[data-vyron-active]{outline:3px solid var(--vyron-highlight) !important;outline-offset:4px !important;box-shadow:0 0 0 8px color-mix(in srgb,var(--vyron-highlight) 18%,transparent),0 0 32px color-mix(in srgb,var(--vyron-highlight) 32%,transparent) !important;transition:outline-color .2s ease,box-shadow .2s ease !important}`;
    document.head?.appendChild(style);
    if (activeIssue) {
      const element = document.querySelector(`[data-vyron-${activeIssue.id}]`);
      if (element) {
        const styledElement = element as HTMLElement;
        element.setAttribute("data-vyron-active", "true");
        styledElement.style.setProperty("--vyron-highlight", resolvedIds.includes(activeIssue.id) ? "#10b981" : "#f59e0b");
        element.scrollIntoView({ block: "center", behavior: "smooth" });
      }
    }
  }, [activeIssue, resolvedIds, ready]);

  return (
    <div className="flex h-full min-h-0 flex-col overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--panel)]">
      <div className="flex h-11 shrink-0 items-center justify-between border-b border-[var(--border)] px-3">
        <div className="flex min-w-0 items-center gap-2">
          <Monitor size={13} className="shrink-0 text-muted" />
          <span className="truncate font-mono text-[9px] text-muted">{target.replace(/^https?:\/\//, "")}</span>
        </div>
        <div className="flex items-center gap-2 text-[9px] text-muted"><span className="hidden items-center gap-1 sm:flex"><Eye size={11} /> Sandboxed DOM</span><span className="rounded border border-[var(--border)] px-1.5 py-0.5">100%</span></div>
      </div>
      <div className="relative min-h-0 flex-1 bg-white">
        <iframe
          ref={iframeRef}
          title="Sandboxed preview of the audited document"
          srcDoc={preview}
          sandbox="allow-same-origin"
          tabIndex={-1}
          onLoad={() => setReady((value) => value + 1)}
          className="h-full w-full border-0 bg-white"
          style={{ pointerEvents: "none", minHeight: compact ? 260 : 420 }}
        />
        {!activeIssue && <div className="pointer-events-none absolute bottom-3 left-1/2 flex -translate-x-1/2 items-center gap-1.5 whitespace-nowrap rounded-full border border-slate-200 bg-white/90 px-3 py-1.5 text-[9px] font-medium text-slate-500 shadow-lg backdrop-blur"><ScanLine size={11} /> Hover an issue to locate it</div>}
      </div>
      {activeIssue && (
        <div className="flex h-9 shrink-0 items-center gap-2 border-t px-3 text-[9px]" style={{ borderColor: resolvedIds.includes(activeIssue.id) ? "rgba(16,185,129,.25)" : "rgba(245,158,11,.25)", background: resolvedIds.includes(activeIssue.id) ? "rgba(16,185,129,.07)" : "rgba(245,158,11,.07)" }}>
          <Globe2 size={11} style={{ color: resolvedIds.includes(activeIssue.id) ? "#10b981" : "#f59e0b" }} />
          <span className="truncate text-soft">{activeIssue.selector} · line {activeIssue.line}</span>
          <span className="ml-auto shrink-0 font-semibold" style={{ color: resolvedIds.includes(activeIssue.id) ? "#10b981" : "#f59e0b" }}>{resolvedIds.includes(activeIssue.id) ? "RESOLVED" : activeIssue.severity.toUpperCase()}</span>
        </div>
      )}
    </div>
  );
}
