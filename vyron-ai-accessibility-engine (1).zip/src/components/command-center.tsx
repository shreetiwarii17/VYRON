"use client";

import { useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import {
  ArrowRight,
  Braces,
  CheckCircle2,
  Code2,
  Globe2,
  Layers3,
  LockKeyhole,
  ScanLine,
  Sparkles,
  WandSparkles,
} from "lucide-react";
import { DEMO_WORLDS } from "@/lib/demo-worlds";
import type { ScanMode, ScanRequest } from "@/lib/accessibility/types";

const SAMPLE_CODE = `<main>
  <h1>Studio updates</h1>
  <h3>Latest release</h3>
  <img src="product-dashboard.png">
  <p style="color:#9aa4b2;background-color:#ffffff">New workflow tools are ready.</p>
  <form><input name="email" placeholder="Work email"><button>Subscribe</button></form>
</main>`;

interface CommandCenterProps {
  onScan: (request: ScanRequest, streamSource?: string) => void;
}

export function CommandCenter({ onScan }: CommandCenterProps) {
  const [mode, setMode] = useState<ScanMode>("url");
  const [url, setUrl] = useState("");
  const [code, setCode] = useState("");
  const [demoId, setDemoId] = useState(DEMO_WORLDS[0].id);
  const [error, setError] = useState("");
  const reduceMotion = useReducedMotion();
  const selectedWorld = DEMO_WORLDS.find((world) => world.id === demoId) ?? DEMO_WORLDS[0];

  const changeMode = (next: ScanMode) => {
    setMode(next);
    setError("");
  };

  const submitUrl = () => {
    const value = url.trim();
    if (!value) return setError("Enter a website URL to begin the audit.");
    let normalized = value;
    if (!/^https?:\/\//i.test(normalized)) normalized = `https://${normalized}`;
    try {
      const parsed = new URL(normalized);
      if (!parsed.hostname.includes(".")) throw new Error("invalid");
    } catch {
      return setError("Enter a valid public URL, such as https://example.com.");
    }
    setError("");
    onScan({ mode: "url", url: normalized });
  };

  const submitCode = () => {
    if (code.trim().length < 20) return setError("Paste an HTML document or fragment with at least 20 characters.");
    setError("");
    onScan({ mode: "code", code }, code);
  };

  const tabs = [
    { id: "demo" as const, label: "Demo Worlds", icon: Layers3 },
    { id: "url" as const, label: "Scan live URL", icon: Globe2 },
    { id: "code" as const, label: "Paste code", icon: Code2 },
  ];

  return (
    <main className="relative mx-auto flex min-h-[calc(100vh-72px)] w-full max-w-[1440px] flex-col px-4 pb-10 pt-12 sm:px-6 sm:pt-16 lg:px-8 lg:pt-20">
      <div className="pointer-events-none absolute left-1/2 top-4 -z-10 h-[440px] w-[min(900px,100%)] -translate-x-1/2 rounded-full opacity-70 blur-[110px]" style={{ background: "var(--ambient-one)" }} />
      <motion.section
        initial={reduceMotion ? false : { opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
        className="mx-auto w-full max-w-4xl text-center"
      >
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-[var(--border)] bg-[var(--panel)] px-3 py-1.5 text-[10px] font-semibold uppercase tracking-[0.16em] text-muted backdrop-blur-xl">
          <span className="pulse-dot h-1.5 w-1.5 rounded-full" style={{ background: "var(--accent)" }} />
          AI accessibility engine · WCAG 2.2
          <span className="h-3 w-px bg-[var(--border)]" />
          <span className="normal-case tracking-normal text-soft">11 rule families</span>
        </div>
        <h1 className="text-balance text-[clamp(2.65rem,6.4vw,5.65rem)] font-semibold leading-[0.98] tracking-[-0.062em]">
          Accessibility, <span className="vyron-logo">resolved.</span>
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-balance text-sm leading-7 text-muted sm:text-base">
          Go beyond another list of errors. VYRON reads your interface, explains the barrier in English and Hindi, then writes the production-ready fix.
        </p>
      </motion.section>

      <motion.section
        initial={reduceMotion ? false : { opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.12, duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
        className="mx-auto mt-10 w-full max-w-5xl"
        aria-label="Start an accessibility scan"
      >
        <div className="mb-3 flex justify-center">
          <div className="glass inline-flex max-w-full gap-1 overflow-x-auto rounded-xl p-1" role="tablist" aria-label="Scan source">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const active = mode === tab.id;
              return (
                <button
                  key={tab.id}
                  role="tab"
                  aria-selected={active}
                  onClick={() => changeMode(tab.id)}
                  className={`relative flex shrink-0 items-center gap-2 rounded-[9px] px-3 py-2 text-xs font-medium transition-colors sm:px-4 ${active ? "text-[var(--text)]" : "text-muted hover:text-soft"}`}
                >
                  {active && <motion.span layoutId="source-tab" className="absolute inset-0 rounded-[9px] border border-[var(--border-strong)] bg-[var(--panel-raised)] shadow-sm" transition={{ type: "spring", stiffness: 450, damping: 35 }} />}
                  <Icon size={14} className="relative" style={active ? { color: "var(--accent-bright)" } : undefined} />
                  <span className="relative">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="glass relative overflow-hidden rounded-2xl p-2 shadow-[0_30px_90px_rgba(0,0,0,.18)] sm:p-3">
          <div className="pointer-events-none absolute inset-x-16 top-0 h-px bg-gradient-to-r from-transparent via-[var(--accent-line)] to-transparent" />
          <AnimatePresence mode="wait" initial={false}>
            {mode === "url" && (
              <motion.div key="url" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.2 }} className="p-3 sm:p-5">
                <form onSubmit={(event) => { event.preventDefault(); submitUrl(); }} className="flex flex-col gap-3 sm:flex-row">
                  <label className="field flex min-h-[68px] flex-1 items-center gap-4 rounded-xl px-5 focus-within:border-[var(--accent-line)] focus-within:shadow-[0_0_0_4px_var(--accent-soft)]">
                    <Globe2 size={22} className="shrink-0 text-muted" />
                    <span className="min-w-0 flex-1">
                      <span className="mb-1 block text-[9px] font-semibold uppercase tracking-[0.16em] text-muted">Enter website URL to scan</span>
                      <input value={url} onChange={(event) => setUrl(event.target.value)} className="w-full bg-transparent text-base font-medium tracking-[-0.02em] outline-none placeholder:font-normal placeholder:text-[var(--faint)] sm:text-lg" placeholder="https://your-website.com" inputMode="url" autoComplete="url" aria-label="Website URL" autoFocus />
                    </span>
                  </label>
                  <button type="submit" className="ai-button flex min-h-[58px] items-center justify-center gap-2 rounded-xl px-6 text-sm font-semibold sm:min-h-[68px]">
                    <WandSparkles size={17} /> Scan & resolve <ArrowRight size={15} />
                  </button>
                </form>
                <div className="mt-4 flex flex-col items-center justify-between gap-2 px-1 text-[10px] text-muted sm:flex-row">
                  <span className="flex items-center gap-1.5"><LockKeyhole size={11} /> Server-side retrieval · public pages only</span>
                  <button type="button" onClick={() => changeMode("demo")} className="font-medium text-[var(--accent-bright)] hover:underline">No URL handy? Enter a Demo World <ArrowRight size={11} className="inline" /></button>
                </div>
              </motion.div>
            )}

            {mode === "demo" && (
              <motion.div key="demo" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.2 }} className="p-2 sm:p-4">
                <div className="mb-4 flex items-end justify-between px-1">
                  <div><p className="text-sm font-semibold">Choose a world to audit</p><p className="mt-1 text-[11px] text-muted">Real HTML, distinct barriers, instant source-level exploration.</p></div>
                  <span className="hidden text-[10px] text-muted sm:block">04 curated environments</span>
                </div>
                <div className="grid gap-3 sm:grid-cols-2">
                  {DEMO_WORLDS.map((world) => {
                    const active = demoId === world.id;
                    return (
                      <button key={world.id} onClick={() => setDemoId(world.id)} className={`group flex gap-3 rounded-xl border p-3 text-left transition-all hover:-translate-y-0.5 ${active ? "border-[var(--accent-line)] bg-[var(--accent-soft)]" : "border-[var(--border)] bg-[var(--panel)] hover:bg-[var(--panel-raised)]"}`} aria-pressed={active}>
                        <span className="relative h-[84px] w-[104px] shrink-0 overflow-hidden rounded-lg border border-black/10" style={{ background: world.surface }}>
                          <span className="absolute inset-x-0 top-0 flex h-4 items-center gap-1 border-b border-black/10 bg-white/40 px-2"><i className="h-1 w-1 rounded-full bg-black/25" /><i className="h-1 w-1 rounded-full bg-black/25" /><i className="h-1 w-1 rounded-full bg-black/25" /></span>
                          <span className="absolute left-3 top-7 h-2 w-12 rounded-sm" style={{ background: world.accent }} />
                          <span className="absolute left-3 top-11 h-1.5 w-20 rounded-sm bg-black/15" />
                          <span className="absolute bottom-3 left-3 h-5 w-10 rounded-sm" style={{ background: world.accent }} />
                          <span className="absolute bottom-3 right-3 h-8 w-8 rounded-sm bg-black/10" />
                        </span>
                        <span className="min-w-0 flex-1 py-0.5">
                          <span className="flex items-center justify-between gap-2"><span className="text-xs font-semibold">{world.name}</span>{active && <CheckCircle2 size={14} style={{ color: "var(--accent)" }} />}</span>
                          <span className="mt-0.5 block text-[9px] font-medium uppercase tracking-[0.12em] text-muted">{world.category}</span>
                          <span className="mt-2 block text-[10px] leading-[1.5] text-muted">{world.description}</span>
                          <span className="mt-1.5 block text-[9px] text-muted">{world.detail}</span>
                        </span>
                      </button>
                    );
                  })}
                </div>
                <div className="mt-4 flex flex-col items-center justify-between gap-3 border-t border-[var(--border)] pt-4 sm:flex-row">
                  <p className="text-center text-[10px] text-muted sm:text-left">Selected: <strong className="font-semibold text-soft">{selectedWorld.name}</strong> · findings are generated from its source</p>
                  <button onClick={() => onScan({ mode: "demo", demoId }, selectedWorld.source)} className="ai-button flex w-full items-center justify-center gap-2 rounded-xl px-5 py-3 text-xs font-semibold sm:w-auto"><ScanLine size={15} /> Scan {selectedWorld.name} <ArrowRight size={14} /></button>
                </div>
              </motion.div>
            )}

            {mode === "code" && (
              <motion.div key="code" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.2 }} className="p-2 sm:p-4">
                <div className="mb-3 flex items-center justify-between px-1">
                  <div><p className="text-sm font-semibold">Audit your actual markup</p><p className="mt-1 text-[11px] text-muted">Paste HTML or a component fragment. Scripts are never executed in preview.</p></div>
                  <button onClick={() => setCode(SAMPLE_CODE)} className="soft-button flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[10px]"><Braces size={12} /> Use sample fragment</button>
                </div>
                <div className="code-window relative overflow-hidden rounded-xl border">
                  <div className="flex h-9 items-center justify-between border-b border-white/10 px-4 text-[9px] text-slate-500"><span>source.html</span><span>{code.length.toLocaleString()} characters</span></div>
                  <textarea value={code} onChange={(event) => setCode(event.target.value)} spellCheck={false} className="custom-scroll block h-[260px] w-full resize-none bg-transparent p-4 font-mono text-xs leading-6 text-slate-300 outline-none placeholder:text-slate-600" placeholder={"<!doctype html>\n<html lang=\"en\">\n  <!-- Paste your HTML here -->\n</html>"} aria-label="HTML source code" />
                </div>
                <div className="mt-4 flex justify-end"><button onClick={submitCode} className="ai-button flex w-full items-center justify-center gap-2 rounded-xl px-5 py-3 text-xs font-semibold sm:w-auto"><Sparkles size={15} /> Audit pasted code <ArrowRight size={14} /></button></div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        <AnimatePresence>
          {error && <motion.p initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} role="alert" className="mt-3 text-center text-xs text-amber-400">{error}</motion.p>}
        </AnimatePresence>
      </motion.section>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="mx-auto mt-8 grid w-full max-w-4xl grid-cols-1 gap-3 sm:grid-cols-3">
        {[
          { icon: ScanLine, title: "Understand the barrier", copy: "WCAG-mapped findings with exact source context." },
          { icon: WandSparkles, title: "Resolve with intelligence", copy: "Reviewable before/after code, never a black box." },
          { icon: Code2, title: "Ship the actual patch", copy: "Unified diffs, bilingual reports, and a real PDF." },
        ].map((item) => <div key={item.title} className="flex items-start gap-3 rounded-xl px-4 py-3 text-left"><item.icon size={15} className="mt-0.5 shrink-0" style={{ color: "var(--accent-bright)" }} /><div><p className="text-[11px] font-semibold text-soft">{item.title}</p><p className="mt-1 text-[10px] leading-relaxed text-muted">{item.copy}</p></div></div>)}
      </motion.div>
    </main>
  );
}
