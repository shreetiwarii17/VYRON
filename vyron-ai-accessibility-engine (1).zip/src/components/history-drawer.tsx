"use client";

import { motion } from "framer-motion";
import { ArrowRight, Clock3, Code2, Globe2, Layers3, Plus, X } from "lucide-react";
import type { ScanRecord } from "@/lib/accessibility/types";

interface HistoryDrawerProps {
  scans: ScanRecord[];
  currentId?: string;
  loading: boolean;
  onClose: () => void;
  onSelect: (scan: ScanRecord) => void;
  onNewScan: () => void;
}

export function HistoryDrawer({ scans, currentId, loading, onClose, onSelect, onNewScan }: HistoryDrawerProps) {
  return (
    <motion.div className="fixed inset-0 z-[70]" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <button className="absolute inset-0 bg-[#020610]/65 backdrop-blur-sm" onClick={onClose} aria-label="Close scan history" />
      <motion.aside role="dialog" aria-modal="true" aria-label="Scan history" initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }} transition={{ type: "spring", stiffness: 360, damping: 36 }} className="absolute right-0 top-0 flex h-full w-full max-w-[410px] flex-col border-l border-[var(--border)] bg-[var(--panel-solid)] shadow-2xl">
        <header className="flex h-[72px] shrink-0 items-center gap-3 border-b border-[var(--border)] px-5"><span className="grid h-9 w-9 place-items-center rounded-[10px] border border-[var(--border)] bg-[var(--panel)] text-muted"><Clock3 size={16} /></span><div className="flex-1"><h2 className="text-sm font-semibold">Scan history</h2><p className="mt-1 text-[9px] text-muted">Your audits and resolutions, preserved</p></div><button onClick={onClose} autoFocus className="soft-button grid h-9 w-9 place-items-center rounded-lg" aria-label="Close history"><X size={15} /></button></header>
        <div className="custom-scroll min-h-0 flex-1 overflow-y-auto p-4">
          {loading ? <div className="space-y-3">{[0, 1, 2].map((item) => <div key={item} className="shimmer h-28 rounded-xl border border-[var(--border)] bg-[var(--panel)]" />)}</div> : scans.length ? <div className="space-y-3">{scans.map((scan) => {
            const Icon = scan.mode === "demo" ? Layers3 : scan.mode === "code" ? Code2 : Globe2;
            const current = currentId === scan.id;
            return <button key={scan.id} onClick={() => onSelect(scan)} className={`group w-full rounded-xl border p-4 text-left transition-all hover:-translate-y-0.5 ${current ? "border-[var(--accent-line)] bg-[var(--accent-soft)]" : "border-[var(--border)] bg-[var(--panel)] hover:bg-[var(--panel-raised)]"}`}>
              <div className="flex items-start gap-3"><span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-[var(--border)] text-muted"><Icon size={14} /></span><div className="min-w-0 flex-1"><div className="flex items-center gap-2"><h3 className="truncate text-[11px] font-semibold text-soft">{scan.title}</h3>{current && <span className="shrink-0 text-[7px] font-bold uppercase tracking-wider text-[var(--accent-bright)]">Open</span>}</div><p className="mt-1 truncate font-mono text-[8px] text-muted">{scan.target}</p></div><div className="text-right"><p className={`font-mono text-xl font-semibold tracking-[-0.05em] ${scan.score >= 85 ? "text-emerald-400" : scan.score >= 60 ? "text-[var(--accent-bright)]" : "text-amber-400"}`}>{scan.score}</p><p className="text-[7px] uppercase tracking-wider text-muted">score</p></div></div>
              <div className="mt-4 flex items-center justify-between border-t border-[var(--border)] pt-3 text-[8px] text-muted"><span>{scan.resolvedIds.length}/{scan.issues.length} resolved · {scan.mode}</span><span className="flex items-center gap-1">{new Date(scan.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}<ArrowRight size={10} className="transition-transform group-hover:translate-x-0.5" /></span></div>
            </button>;
          })}</div> : <div className="flex h-full min-h-[400px] flex-col items-center justify-center text-center"><Clock3 size={26} className="mb-4 text-muted" /><h3 className="text-sm font-semibold">No saved audits yet</h3><p className="mt-2 max-w-[240px] text-[10px] leading-relaxed text-muted">Run a Demo World, URL, or pasted-code scan. It will appear here with its resolution state.</p></div>}
        </div>
        <footer className="shrink-0 border-t border-[var(--border)] p-4"><button onClick={onNewScan} className="ai-button flex w-full items-center justify-center gap-2 rounded-xl py-3 text-[11px] font-semibold"><Plus size={14} /> Start a new scan</button></footer>
      </motion.aside>
    </motion.div>
  );
}
