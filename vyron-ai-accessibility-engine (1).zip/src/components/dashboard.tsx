"use client";

import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Clipboard,
  Code2,
  Columns2,
  FileDown,
  FileText,
  Globe2,
  Grid2X2,
  ListFilter,
  RotateCw,
  Search,
  ShieldCheck,
  Sparkles,
  WandSparkles,
  X,
} from "lucide-react";
import type { AccessibilityIssue, ReportLanguage, ScanRecord, Severity } from "@/lib/accessibility/types";
import { calculateScore } from "@/lib/accessibility/types";
import { createUnifiedPatch } from "@/lib/accessibility/patch";
import { copyToClipboard } from "@/lib/client-utils";
import { ScoreRing } from "@/components/score-ring";
import { SitePreview } from "@/components/site-preview";
import { IssueCard } from "@/components/issue-card";

interface DashboardProps {
  scan: ScanRecord;
  language: ReportLanguage;
  onLanguageChange: (language: ReportLanguage) => void;
  onRescan: () => void;
  onResolve: (issue: AccessibilityIssue) => void;
  onReport: () => void;
  onDownloadPdf: () => void;
  onToast: (message: string) => void;
}

type Filter = "all" | Severity;

export function Dashboard({ scan, language, onLanguageChange, onRescan, onResolve, onReport, onDownloadPdf, onToast }: DashboardProps) {
  const [layout, setLayout] = useState<"split" | "grid">("split");

  useEffect(() => {
    try {
      if (window.localStorage.getItem("vyron-layout") === "grid") setLayout("grid");
    } catch {
      // Split view remains the default when storage is restricted.
    }
  }, []);
  const [filter, setFilter] = useState<Filter>("all");
  const [query, setQuery] = useState("");
  const [activeIssue, setActiveIssue] = useState<AccessibilityIssue | null>(null);
  const resolved = new Set(scan.resolvedIds);
  const counts = {
    critical: scan.issues.filter((issue) => issue.severity === "critical").length,
    serious: scan.issues.filter((issue) => issue.severity === "serious").length,
    moderate: scan.issues.filter((issue) => issue.severity === "moderate").length,
  };
  const openCount = scan.issues.length - scan.resolvedIds.length;
  const currentPassedRules = 11 - new Set(scan.issues.filter((issue) => !resolved.has(issue.id)).map((issue) => issue.rule)).size;
  const nextIssue = scan.issues.find((issue) => !resolved.has(issue.id));
  const patch = useMemo(() => createUnifiedPatch(scan.source, scan.issues, scan.resolvedIds), [scan]);
  const visibleIssues = useMemo(() => scan.issues.filter((issue) => {
    const severityMatch = filter === "all" || issue.severity === filter;
    const haystack = `${issue.title} ${issue.description} ${issue.wcag} ${issue.rule} ${issue.snippet}`.toLowerCase();
    return severityMatch && haystack.includes(query.trim().toLowerCase());
  }), [scan.issues, filter, query]);

  const changeLayout = (value: "split" | "grid") => {
    setLayout(value);
    try { window.localStorage.setItem("vyron-layout", value); } catch { /* layout persistence is optional */ }
  };

  const copyPatch = async () => {
    await copyToClipboard(patch);
    onToast("Unified patch copied to clipboard.");
  };

  const modeLabel = scan.mode === "demo" ? "Demo World" : scan.mode === "code" ? "Pasted source" : scan.isSimulated ? "Simulated snapshot" : "Live source";
  const sourceLines = scan.source.split("\n").length;
  const summaryText = openCount === 0
    ? "Every detected barrier has a reviewed resolution. Your patched source is ready for final manual verification."
    : counts.critical > 0
      ? `${counts.critical} critical ${counts.critical === 1 ? "barrier is" : "barriers are"} blocking dependable assistive technology use. Start there for the highest-impact score and usability gain.`
      : "The critical path is clear. Resolve the remaining serious and moderate findings to strengthen WCAG alignment.";

  const issueSection = (severity: Severity) => {
    const items = visibleIssues.filter((issue) => issue.severity === severity);
    if (!items.length) return null;
    const labels = { critical: "Critical", serious: "Serious", moderate: "Moderate" };
    return (
      <section key={severity} className="space-y-3">
        <div className="flex items-center gap-2 px-0.5">
          <span className={`h-1.5 w-1.5 rounded-full ${severity === "moderate" ? "bg-slate-400" : "bg-amber-400"}`} />
          <h2 className="text-[10px] font-semibold uppercase tracking-[0.13em] text-soft">{labels[severity]}</h2>
          <span className="rounded-full border border-[var(--border)] px-1.5 py-0.5 font-mono text-[8px] text-muted">{items.length}</span>
          <span className="h-px flex-1 bg-[var(--border)]" />
        </div>
        <div className={layout === "grid" ? "grid gap-3 md:grid-cols-2 2xl:grid-cols-3" : "space-y-3"}>
          {items.map((issue) => <IssueCard key={issue.id} issue={issue} resolved={resolved.has(issue.id)} active={activeIssue?.id === issue.id} onHover={setActiveIssue} onResolve={onResolve} onSelect={setActiveIssue} compact={layout === "split"} />)}
        </div>
      </section>
    );
  };

  return (
    <main className="mx-auto w-full max-w-[1600px] px-4 pb-16 pt-5 sm:px-6 lg:px-8">
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="flex min-w-0 flex-1 items-center gap-2 text-[10px] text-muted"><Globe2 size={13} className="shrink-0" /><span className="hidden shrink-0 sm:inline">Audits</span><span className="hidden shrink-0 sm:inline">/</span><span className="truncate text-soft">{scan.target}</span><span className={`shrink-0 rounded-md border px-1.5 py-0.5 text-[8px] font-semibold ${scan.isSimulated ? "border-amber-400/20 bg-amber-400/10 text-amber-400" : "border-[var(--border)]"}`}>{modeLabel}</span></div>
        <div className="flex flex-wrap items-center gap-2">
          <button onClick={onRescan} className="soft-button flex h-9 items-center gap-2 rounded-lg px-3 text-[10px] font-medium"><RotateCw size={13} /> Rescan</button>
          <div className="flex h-9 items-center rounded-lg border border-[var(--border)] bg-[var(--panel)] p-0.5"><button onClick={() => onLanguageChange("en")} className={`h-full rounded-md px-2 text-[9px] font-semibold ${language === "en" ? "bg-[var(--accent-soft)] text-[var(--accent-bright)]" : "text-muted"}`}>EN</button><button onClick={() => onLanguageChange("hi")} lang="hi" className={`h-full rounded-md px-2 text-[10px] font-semibold ${language === "hi" ? "bg-[var(--accent-soft)] text-[var(--accent-bright)]" : "text-muted"}`}>हि</button></div>
          <button onClick={onReport} className="soft-button flex h-9 items-center gap-2 rounded-lg px-3 text-[10px] font-medium"><FileText size={13} /> Report</button>
          <button onClick={onDownloadPdf} className="soft-button flex h-9 items-center gap-2 rounded-lg px-3 text-[10px] font-medium"><FileDown size={13} /> <span className="hidden sm:inline">PDF</span></button>
          <button onClick={copyPatch} disabled={!scan.resolvedIds.length} className="ai-button flex h-9 items-center gap-2 rounded-lg px-3 text-[10px] font-semibold disabled:opacity-40" title={!scan.resolvedIds.length ? "Resolve a finding to create a patch" : "Copy all resolved fixes as a unified diff"}><Clipboard size={13} /> <span className="hidden sm:inline">Copy patch</span></button>
        </div>
      </div>

      <motion.section initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="glass relative overflow-hidden rounded-2xl">
        <div className="pointer-events-none absolute inset-x-10 top-0 h-px bg-gradient-to-r from-transparent via-[var(--accent-line)] to-transparent" />
        <div className="grid items-center gap-6 p-5 sm:p-7 lg:grid-cols-[220px_1fr_310px] lg:gap-8">
          <div className="flex justify-center"><ScoreRing score={scan.score} initialScore={scan.initialScore} /></div>
          <div className="text-center lg:text-left">
            <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-emerald-400/20 bg-emerald-400/[.06] px-2.5 py-1 text-[8px] font-semibold uppercase tracking-[0.14em] text-emerald-400"><CheckCircle2 size={10} /> Audit complete · source mapped</div>
            <h1 className="text-balance text-2xl font-semibold tracking-[-0.045em] sm:text-3xl">{scan.title}</h1>
            <p className="mt-3 max-w-xl text-[11px] leading-[1.8] text-muted">{summaryText}</p>
            <div className="mt-5 flex flex-col justify-center gap-2 sm:flex-row lg:justify-start">
              {nextIssue ? <button onClick={() => onResolve(nextIssue)} className="ai-button flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-[11px] font-semibold"><WandSparkles size={14} /> Resolve next {nextIssue.severity} issue <ArrowRight size={13} /></button> : <button onClick={copyPatch} className="ai-button flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-[11px] font-semibold"><Clipboard size={14} /> Copy completed patch <ArrowRight size={13} /></button>}
              <button onClick={onReport} className="soft-button flex items-center justify-center gap-2 rounded-xl px-4 py-3 text-[11px] font-medium"><FileText size={14} /> Read {language === "hi" ? "Hindi" : "English"} summary</button>
            </div>
            <p className="mt-4 font-mono text-[8px] text-[var(--faint)]">{sourceLines.toLocaleString()} source lines · {currentPassedRules}/11 rule families passing · {scan.durationMs}ms engine run</p>
          </div>

          <aside className="rounded-xl border border-[var(--border)] bg-[var(--panel)] p-4" aria-label="Scan summary">
            <div className="mb-4 flex items-center justify-between"><h2 className="text-[10px] font-semibold uppercase tracking-[0.13em]">Scan summary</h2><ShieldCheck size={14} style={{ color: "var(--accent)" }} /></div>
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: "Open issues", value: openCount, icon: AlertTriangle, color: openCount ? "#f5a524" : "#34d399" },
                { label: "AI resolved", value: scan.resolvedIds.length, icon: Sparkles, color: "#34d399" },
                { label: "Critical", value: counts.critical, icon: AlertTriangle, color: "#f5a524" },
                { label: "Rules passed", value: currentPassedRules, icon: CheckCircle2, color: "var(--accent-bright)" },
              ].map((item) => <div key={item.label} className="rounded-lg border border-[var(--border)] bg-[var(--bg)]/30 p-3"><div className="flex items-center justify-between"><span className="text-[8px] text-muted">{item.label}</span><item.icon size={11} style={{ color: item.color }} /></div><p className="mt-2 font-mono text-xl font-semibold tracking-[-0.05em]" style={{ color: item.color }}>{String(item.value).padStart(2, "0")}</p></div>)}
            </div>
            <div className="mt-4"><div className="mb-2 flex justify-between text-[8px] text-muted"><span>Resolution progress</span><span>{scan.issues.length ? Math.round((scan.resolvedIds.length / scan.issues.length) * 100) : 100}%</span></div><div className="h-1.5 overflow-hidden rounded-full bg-[var(--border)]"><motion.div className="h-full rounded-full bg-gradient-to-r from-[var(--accent)] to-emerald-400" animate={{ width: `${scan.issues.length ? (scan.resolvedIds.length / scan.issues.length) * 100 : 100}%` }} /></div></div>
            <p className="mt-3 text-[8px] leading-relaxed text-muted">Potential score after all fixes: <strong className="font-mono text-emerald-400">{calculateScore(scan.issues, scan.issues.map((issue) => issue.id))}</strong>/100</p>
          </aside>
        </div>
      </motion.section>

      {scan.notice && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-4 flex items-start gap-3 rounded-xl border border-amber-400/20 bg-amber-400/[.055] p-4 text-[10px] leading-relaxed text-amber-300"><AlertTriangle size={15} className="mt-0.5 shrink-0" /><div><strong className="mb-1 block text-[9px] uppercase tracking-wider">Labeled simulation — not live-page evidence</strong>{scan.notice}</div></motion.div>}

      <div className="mb-4 mt-6 flex flex-col gap-3 xl:flex-row xl:items-center">
        <div className="flex items-center gap-2"><h2 className="text-sm font-semibold tracking-[-0.025em]">Resolution queue</h2><span className="rounded-full border border-[var(--border)] px-2 py-0.5 font-mono text-[9px] text-muted">{visibleIssues.length}</span></div>
        <div className="flex flex-1 flex-wrap items-center gap-2 xl:justify-end">
          <div className="field flex h-9 min-w-[180px] flex-1 items-center gap-2 rounded-lg px-3 sm:max-w-[240px]"><Search size={12} className="shrink-0 text-muted" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search WCAG or source…" className="min-w-0 flex-1 bg-transparent text-[10px] outline-none placeholder:text-[var(--faint)]" aria-label="Search issues" />{query && <button onClick={() => setQuery("")} aria-label="Clear search"><X size={11} className="text-muted" /></button>}</div>
          <div className="flex h-9 items-center gap-0.5 rounded-lg border border-[var(--border)] bg-[var(--panel)] p-0.5"><ListFilter size={11} className="mx-2 text-muted" />{(["all", "critical", "serious", "moderate"] as Filter[]).map((item) => <button key={item} onClick={() => setFilter(item)} className={`rounded-md px-2 py-1.5 text-[9px] font-medium capitalize ${filter === item ? "bg-[var(--accent-soft)] text-[var(--accent-bright)]" : "text-muted hover:text-soft"}`}>{item === "all" ? `All ${scan.issues.length}` : `${item} ${counts[item]}`}</button>)}</div>
          <div className="flex h-9 rounded-lg border border-[var(--border)] bg-[var(--panel)] p-0.5" aria-label="Results layout"><button onClick={() => changeLayout("split")} className={`flex items-center gap-1.5 rounded-md px-2.5 text-[9px] font-medium ${layout === "split" ? "bg-[var(--accent-soft)] text-[var(--accent-bright)]" : "text-muted"}`} aria-pressed={layout === "split"}><Columns2 size={12} /> Split view</button><button onClick={() => changeLayout("grid")} className={`flex items-center gap-1.5 rounded-md px-2.5 text-[9px] font-medium ${layout === "grid" ? "bg-[var(--accent-soft)] text-[var(--accent-bright)]" : "text-muted"}`} aria-pressed={layout === "grid"}><Grid2X2 size={12} /> Issues grid</button></div>
        </div>
      </div>

      <AnimatePresence mode="wait" initial={false}>
        <motion.div key={layout} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} transition={{ duration: 0.22 }}>
          {layout === "split" ? (
            <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1.08fr)_minmax(390px,.92fr)]">
              <div className="h-[440px] xl:sticky xl:top-[92px] xl:h-[calc(100vh-112px)] xl:min-h-[560px]"><SitePreview source={scan.source} issues={scan.issues} activeIssue={activeIssue} resolvedIds={scan.resolvedIds} target={scan.target} mode={scan.mode} isSimulated={scan.isSimulated} /></div>
              <div className="space-y-5">{(["critical", "serious", "moderate"] as Severity[]).map(issueSection)}{!visibleIssues.length && <EmptyResults hasIssues={scan.issues.length > 0} clear={() => { setFilter("all"); setQuery(""); }} />}</div>
            </div>
          ) : (
            <div className="space-y-7">{(["critical", "serious", "moderate"] as Severity[]).map(issueSection)}{!visibleIssues.length && <EmptyResults hasIssues={scan.issues.length > 0} clear={() => { setFilter("all"); setQuery(""); }} />}</div>
          )}
        </motion.div>
      </AnimatePresence>

      <div className="mt-8 flex flex-col items-center justify-between gap-3 border-t border-[var(--border)] pt-5 text-[9px] text-muted sm:flex-row"><p className="flex items-center gap-2"><Code2 size={12} /> Automated source analysis is a release aid, not a substitute for manual WCAG testing.</p><button onClick={onRescan} className="flex items-center gap-1.5 font-medium text-[var(--accent-bright)] hover:underline"><RotateCw size={11} /> Rescan original source</button></div>
    </main>
  );
}

function EmptyResults({ hasIssues, clear }: { hasIssues: boolean; clear: () => void }) {
  return <div className="glass flex min-h-[260px] flex-col items-center justify-center rounded-xl p-8 text-center"><CheckCircle2 size={28} className="mb-4 text-emerald-400" /><h3 className="text-sm font-semibold">{hasIssues ? "No findings match these filters" : "No automated violations detected"}</h3><p className="mt-2 max-w-sm text-[10px] leading-relaxed text-muted">{hasIssues ? "Clear your search and severity filters to return to the full resolution queue." : "This source passed the implemented rule families. Continue with keyboard, zoom, and screen reader testing for complete coverage."}</p>{hasIssues && <button onClick={clear} className="soft-button mt-4 rounded-lg px-3 py-2 text-[10px]">Clear filters</button>}</div>;
}
