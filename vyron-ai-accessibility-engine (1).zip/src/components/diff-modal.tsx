"use client";

import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import {
  ArrowRight,
  Check,
  CheckCircle2,
  Clipboard,
  Code2,
  FileDown,
  Languages,
  LoaderCircle,
  RotateCcw,
  Sparkles,
  WandSparkles,
  X,
} from "lucide-react";
import type { AccessibilityIssue, ReportLanguage, ScanRecord } from "@/lib/accessibility/types";
import { SEVERITY_WEIGHT } from "@/lib/accessibility/types";
import { createUnifiedPatch } from "@/lib/accessibility/patch";
import { copyToClipboard } from "@/lib/client-utils";
import { ISSUE_TITLE_HI } from "@/lib/accessibility/reporting";

interface DiffModalProps {
  issue: AccessibilityIssue | null;
  scan: ScanRecord;
  language: ReportLanguage;
  onClose: () => void;
  onApply: (issue: AccessibilityIssue) => Promise<void>;
  onUndo: (issue: AccessibilityIssue) => Promise<void>;
  onDownloadPdf: () => void;
  onToast: (message: string) => void;
}

export function DiffModal({ issue, scan, language, onClose, onApply, onUndo, onDownloadPdf, onToast }: DiffModalProps) {
  const [stage, setStage] = useState<"generating" | "diff" | "success">("generating");
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState(false);
  const reduceMotion = useReducedMotion();
  const resolved = issue ? scan.resolvedIds.includes(issue.id) : false;

  useEffect(() => {
    if (!issue) return;
    setCopied(false);
    setBusy(false);
    if (resolved) {
      setStage("diff");
      return;
    }
    setStage("generating");
    const timer = window.setTimeout(() => setStage("diff"), reduceMotion ? 100 : 1050);
    return () => window.clearTimeout(timer);
    // Reset only when a new issue is opened; resolution state is handled by apply.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [issue?.id, reduceMotion]);

  useEffect(() => {
    if (!issue) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const keydown = (event: KeyboardEvent) => {
      if (event.key === "Escape" && !busy) onClose();
    };
    document.addEventListener("keydown", keydown);
    return () => {
      document.body.style.overflow = previous;
      document.removeEventListener("keydown", keydown);
    };
  }, [issue, busy, onClose]);

  const patch = useMemo(() => issue ? createUnifiedPatch(scan.source, scan.issues, scan.resolvedIds) : "", [issue, scan]);

  if (!issue) return null;

  const apply = async () => {
    setBusy(true);
    try {
      await onApply(issue);
      setStage("success");
    } catch {
      // The shared controller displays the persistence error.
    } finally {
      setBusy(false);
    }
  };

  const undo = async () => {
    setBusy(true);
    try {
      await onUndo(issue);
      setStage("diff");
    } catch {
      // Keep the reviewed diff open if the update could not be saved.
    } finally {
      setBusy(false);
    }
  };

  const copy = async (contents: string, message: string) => {
    await copyToClipboard(contents);
    setCopied(true);
    onToast(message);
    window.setTimeout(() => setCopied(false), 1800);
  };

  return (
    <motion.div className="fixed inset-0 z-[80] flex items-center justify-center p-0 sm:p-5" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <motion.button aria-label="Close resolution dialog" className="absolute inset-0 bg-[#020610]/80 backdrop-blur-md" onClick={() => !busy && onClose()} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} />
      <motion.section
        role="dialog"
        aria-modal="true"
        aria-labelledby="diff-title"
        initial={reduceMotion ? { opacity: 0 } : { opacity: 0, y: 28, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={reduceMotion ? { opacity: 0 } : { opacity: 0, y: 16, scale: 0.98 }}
        transition={{ type: "spring", stiffness: 360, damping: 32 }}
        className="relative flex h-full max-h-[940px] w-full max-w-[1240px] flex-col overflow-hidden border-[var(--border)] bg-[var(--panel-solid)] shadow-[0_40px_140px_rgba(0,0,0,.5)] sm:h-[92vh] sm:rounded-2xl sm:border"
      >
        <header className="flex min-h-[70px] shrink-0 items-center gap-3 border-b border-[var(--border)] px-4 sm:px-6">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-[10px] border border-[var(--accent-line)] bg-[var(--accent-soft)] text-[var(--accent-bright)]"><WandSparkles size={17} /></span>
          <div className="min-w-0 flex-1"><div className="flex items-center gap-2"><h2 id="diff-title" className="truncate text-sm font-semibold tracking-[-0.02em]">{stage === "success" ? "Resolution ready to ship" : issue.title}</h2><span className="hidden rounded border border-amber-400/20 bg-amber-400/10 px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wider text-amber-400 sm:inline">{issue.severity}</span></div><p className="mt-1 truncate text-[9px] text-muted">WCAG {issue.wcag} · {issue.wcagTitle} · line {issue.line}</p></div>
          <button onClick={onClose} disabled={busy} autoFocus className="soft-button grid h-9 w-9 shrink-0 place-items-center rounded-lg" aria-label="Close diff"><X size={16} /></button>
        </header>

        <div className="custom-scroll min-h-0 flex-1 overflow-y-auto">
          <AnimatePresence mode="wait">
            {stage === "generating" && (
              <motion.div key="generating" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, y: -10 }} className="flex min-h-[560px] flex-col items-center justify-center p-6">
                <div className="relative mb-7 grid h-24 w-24 place-items-center">
                  <motion.span className="absolute inset-0 rounded-full border border-dashed border-[var(--accent-line)]" animate={reduceMotion ? undefined : { rotate: 360 }} transition={{ duration: 7, repeat: Infinity, ease: "linear" }} />
                  <motion.span className="absolute inset-3 rounded-full border border-[var(--accent-soft)] bg-[var(--accent-soft)]" animate={reduceMotion ? undefined : { scale: [1, 1.08, 1] }} transition={{ duration: 1.6, repeat: Infinity }} />
                  <Sparkles size={28} style={{ color: "var(--accent-bright)" }} />
                </div>
                <h3 className="text-xl font-semibold tracking-[-0.035em]">Generating fix<span className="animate-pulse">...</span></h3>
                <p className="mt-2 max-w-md text-center text-xs leading-6 text-muted">Analyzing {issue.rule} at line {issue.line}, preserving surrounding behavior, and preparing a minimal source edit.</p>
                <div className="mt-9 grid w-full max-w-3xl gap-3 sm:grid-cols-2">
                  {[0, 1].map((panel) => <div key={panel} className={`shimmer rounded-xl border p-4 ${panel === 0 ? "code-broken" : "code-fixed"}`}><div className="mb-4 h-2 w-20 rounded bg-white/10" />{[92, 74, 84, 48].map((width, index) => <div key={index} className="mb-3 h-2 rounded bg-white/[.07]" style={{ width: `${width}%` }} />)}</div>)}
                </div>
                <div className="mt-6 flex items-center gap-2 text-[9px] font-medium uppercase tracking-[0.15em] text-muted"><LoaderCircle size={12} className="animate-spin" /> VYRON FIX ENGINE</div>
              </motion.div>
            )}

            {stage === "diff" && (
              <motion.div key="diff" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="p-4 sm:p-6">
                <div className="mb-4 flex flex-col justify-between gap-3 sm:flex-row sm:items-center"><div><p className="text-xs font-semibold">Review the exact change</p><p className="mt-1 text-[10px] text-muted">Nothing ships until you approve it. Surrounding markup stays untouched.</p></div><span className="inline-flex w-fit items-center gap-1.5 rounded-full border border-[var(--accent-line)] bg-[var(--accent-soft)] px-2.5 py-1 text-[9px] font-medium text-[var(--accent-bright)]"><Sparkles size={10} /> {issue.fixLabel}</span></div>
                <div className="grid overflow-hidden rounded-xl border border-[var(--border)] lg:grid-cols-2">
                  <div className="code-window code-broken min-w-0 border-b border-red-400/15 lg:border-b-0 lg:border-r">
                    <div className="flex h-10 items-center justify-between border-b border-red-400/10 px-4"><span className="flex items-center gap-2 text-[10px] font-semibold text-red-300"><span className="h-1.5 w-1.5 rounded-full bg-red-400" /> Broken · original</span><span className="font-mono text-[8px] text-slate-500">− inaccessible</span></div>
                    <pre className="custom-scroll max-h-[310px] min-h-[180px] overflow-auto whitespace-pre-wrap break-words p-4 font-mono text-[10px] leading-[1.75] text-red-100/65 sm:text-[11px]">{issue.snippet}</pre>
                  </div>
                  <div className="code-window code-fixed min-w-0">
                    <div className="flex h-10 items-center justify-between border-b border-emerald-400/10 px-4"><span className="flex items-center gap-2 text-[10px] font-semibold text-emerald-300"><span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> Fixed · VYRON AI</span><span className="font-mono text-[8px] text-slate-500">+ accessible</span></div>
                    <pre className="custom-scroll max-h-[310px] min-h-[180px] overflow-auto whitespace-pre-wrap break-words p-4 font-mono text-[10px] leading-[1.75] text-emerald-100/75 sm:text-[11px]">{issue.fixedSnippet}</pre>
                  </div>
                </div>

                <div className="mt-4 overflow-hidden rounded-xl border border-[var(--accent-line)] bg-[var(--accent-soft)]">
                  <div className="flex items-center gap-2 border-b border-[var(--accent-line)] px-4 py-3 text-[10px] font-semibold text-[var(--accent-bright)]"><Sparkles size={13} /> AI Insights <span className="ml-auto flex items-center gap-1 text-[8px] font-medium uppercase tracking-wider text-muted"><Languages size={11} /> English + हिन्दी</span></div>
                  <div className="grid gap-5 p-4 sm:p-5 lg:grid-cols-2">
                    <div><p className="mb-2 text-[8px] font-bold uppercase tracking-[0.15em] text-muted">English · Why this matters</p><p className="text-[11px] leading-[1.8] text-soft">{issue.explanationEn}</p></div>
                    <div lang="hi"><p className="mb-2 text-[8px] font-bold uppercase tracking-[0.15em] text-muted">हिन्दी · यह समाधान क्यों ज़रूरी है</p><p className="text-[12px] leading-[1.9] text-soft">{issue.explanationHi}</p></div>
                  </div>
                  {issue.context && <div className="border-t border-[var(--accent-line)] px-4 py-2.5 font-mono text-[9px] leading-relaxed text-muted">{issue.context}</div>}
                </div>
              </motion.div>
            )}

            {stage === "success" && (
              <motion.div key="success" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="relative flex min-h-[570px] flex-col items-center justify-center overflow-hidden p-6 text-center">
                <motion.div initial={reduceMotion ? false : { scale: 0.5, rotate: -20 }} animate={{ scale: 1, rotate: 0 }} transition={{ type: "spring", stiffness: 280, damping: 18 }} className="relative mb-7 grid h-24 w-24 place-items-center rounded-full border border-emerald-400/25 bg-emerald-400/10 text-emerald-400 shadow-[0_0_70px_rgba(52,211,153,.12)]"><CheckCircle2 size={42} strokeWidth={1.5} /><motion.span className="absolute inset-0 rounded-full border border-emerald-400/30" animate={reduceMotion ? undefined : { scale: [1, 1.35], opacity: [0.6, 0] }} transition={{ duration: 1.8, repeat: Infinity }} /></motion.div>
                <p className="mb-2 text-[9px] font-bold uppercase tracking-[0.2em] text-emerald-400">Red error → green resolution</p>
                <h3 className="text-3xl font-semibold tracking-[-0.05em]">That barrier is behind you.</h3>
                <p className="mt-3 max-w-lg text-xs leading-6 text-muted">The fix is saved to this audit and the score increased by {SEVERITY_WEIGHT[issue.severity]} points. Export the patch or keep moving through the remaining findings.</p>
                <div className="mt-6 flex items-center gap-3 rounded-xl border border-[var(--border)] bg-[var(--panel)] px-5 py-3"><div><p className="text-[8px] uppercase tracking-wider text-muted">Previous score</p><p className="mt-1 font-mono text-sm text-muted line-through">{scan.score - SEVERITY_WEIGHT[issue.severity]}</p></div><ArrowRight size={15} className="text-emerald-400" /><div><p className="text-[8px] uppercase tracking-wider text-muted">Current score</p><p className="mt-1 font-mono text-lg font-semibold text-emerald-400">{scan.score}</p></div></div>
                <div className="mt-7 flex w-full max-w-xl flex-col justify-center gap-2 sm:flex-row"><button onClick={() => copy(patch, "Unified patch copied to clipboard.")} className="ai-button flex items-center justify-center gap-2 rounded-xl px-5 py-3 text-xs font-semibold">{copied ? <Check size={15} /> : <Clipboard size={15} />} {copied ? "Patch copied" : "One-Click Copy Patch"}</button><button onClick={onDownloadPdf} className="soft-button flex items-center justify-center gap-2 rounded-xl px-5 py-3 text-xs font-semibold"><FileDown size={15} /> Download Full Report (PDF)</button></div>
                <button onClick={onClose} className="mt-5 flex items-center gap-2 text-[11px] font-medium text-muted transition-colors hover:text-[var(--text)]">Continue resolving <ArrowRight size={12} /></button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {stage === "diff" && (
          <footer className="flex shrink-0 flex-col gap-3 border-t border-[var(--border)] bg-[var(--panel)] px-4 py-3 sm:flex-row sm:items-center sm:px-6">
            <button onClick={() => copy(issue.fixedSnippet, "Fixed code snippet copied.")} className="soft-button flex items-center justify-center gap-2 rounded-lg px-3 py-2.5 text-[10px] font-medium"><Code2 size={13} /> {copied ? "Copied" : "Copy fixed snippet"}</button>
            {resolved && <button onClick={undo} disabled={busy} className="soft-button flex items-center justify-center gap-2 rounded-lg px-3 py-2.5 text-[10px] font-medium"><RotateCcw size={13} /> Undo resolution</button>}
            <p className="hidden flex-1 text-center text-[9px] text-muted lg:block">Source edit validated against the original audit</p>
            {resolved ? <span className="flex items-center justify-center gap-2 px-3 text-[10px] font-semibold text-emerald-400"><CheckCircle2 size={14} /> Applied to workspace</span> : <button onClick={apply} disabled={busy} className="ai-button flex items-center justify-center gap-2 rounded-lg px-5 py-2.5 text-[11px] font-semibold disabled:opacity-60">{busy ? <LoaderCircle size={14} className="animate-spin" /> : <Sparkles size={14} />} {busy ? "Applying to workspace…" : "Apply this fix"}</button>}
          </footer>
        )}
        <span className="sr-only" lang="hi">{ISSUE_TITLE_HI[issue.rule]}</span>
        <span className="sr-only">{language === "hi" ? "रिपोर्ट भाषा हिन्दी" : "Report language English"}</span>
      </motion.section>
    </motion.div>
  );
}
