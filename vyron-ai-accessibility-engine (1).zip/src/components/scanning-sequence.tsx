"use client";

import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import {
  Braces,
  Check,
  Contrast,
  FileSearch,
  Globe2,
  Scale,
  WandSparkles,
} from "lucide-react";

const STAGES = [
  { label: "Reading document structure", detail: "Parsing semantic elements and source positions", icon: Globe2, rule: "DOM / DOCUMENT" },
  { label: "Mapping accessible names", detail: "Checking controls, images, links, and form fields", icon: Braces, rule: "ACCNAME / ARIA" },
  { label: "Evaluating WCAG 2.2", detail: "Testing Level A and AA rule families", icon: Scale, rule: "WCAG / CONFORMANCE" },
  { label: "Measuring visual perception", detail: "Computing luminance, contrast, and focus visibility", icon: Contrast, rule: "COLOR / FOCUS" },
  { label: "Preparing precise resolutions", detail: "Locating edits and building bilingual explanations", icon: WandSparkles, rule: "FIX / SYNTHESIS" },
];

interface ScanningSequenceProps {
  target: string;
  source?: string;
}

export function ScanningSequence({ target, source }: ScanningSequenceProps) {
  const [stage, setStage] = useState(0);
  const [lineOffset, setLineOffset] = useState(0);
  const reduceMotion = useReducedMotion();
  const sourceLines = useMemo(() => {
    const lines = (source?.trim() || `<!doctype html>\n<html>\n  <head><title>Live document</title></head>\n  <main>\n    <h1>Reading page structure</h1>\n    <img src="hero-image.jpg">\n    <button><svg></svg></button>\n    <input name="email">\n  </main>\n</html>`)
      .split("\n")
      .map((line) => line.trim())
      .filter((line) => line.length > 1 && !line.startsWith("<style") && !line.startsWith("*"));
    return lines.length ? lines.slice(0, 36) : ["<main>", "<h1>Document</h1>", "</main>"];
  }, [source]);

  useEffect(() => {
    if (reduceMotion) {
      setStage(STAGES.length - 1);
      return;
    }
    const stageTimer = window.setInterval(() => setStage((value) => Math.min(value + 1, STAGES.length - 1)), 640);
    const lineTimer = window.setInterval(() => setLineOffset((value) => value + 1), 160);
    return () => {
      window.clearInterval(stageTimer);
      window.clearInterval(lineTimer);
    };
  }, [reduceMotion]);

  const visibleLines = Array.from({ length: 10 }, (_, index) => sourceLines[(lineOffset + index) % sourceLines.length]);
  const progress = reduceMotion ? 92 : Math.min(96, 12 + stage * 20);

  return (
    <main className="mx-auto flex min-h-[calc(100vh-72px)] w-full max-w-6xl flex-col justify-center px-4 py-10 sm:px-6 lg:px-8">
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mb-8 text-center">
        <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-[var(--accent-line)] bg-[var(--accent-soft)] px-3 py-1.5 text-[10px] font-medium uppercase tracking-[0.16em] text-[var(--accent-bright)]">
          <span className="pulse-dot h-1.5 w-1.5 rounded-full bg-[var(--accent)]" /> Live analysis sequence
        </div>
        <h1 className="text-3xl font-semibold tracking-[-0.045em] sm:text-4xl">Reading the interface.<br /><span className="text-muted">Finding the path to resolved.</span></h1>
        <p className="mx-auto mt-4 max-w-xl truncate px-4 font-mono text-[10px] text-muted">{target}</p>
      </motion.div>

      <div className="glass relative overflow-hidden rounded-2xl shadow-[0_32px_100px_rgba(0,0,0,.2)]">
        <div className="scan-line absolute left-0 top-0 z-10 h-px w-full" />
        <div className="grid min-h-[430px] lg:grid-cols-[1.15fr_.85fr]">
          <div className="code-window relative overflow-hidden border-b border-white/10 lg:border-b-0 lg:border-r">
            <div className="flex h-12 items-center justify-between border-b border-white/10 px-5">
              <div className="flex items-center gap-2 text-[10px] text-slate-400"><FileSearch size={13} /> source-stream.html</div>
              <div className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full bg-red-400/70" /><span className="h-1.5 w-1.5 rounded-full bg-amber-400/70" /><span className="h-1.5 w-1.5 rounded-full bg-emerald-400/70" /></div>
            </div>
            <div className="relative h-[310px] overflow-hidden px-3 py-5 sm:px-5">
              <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(transparent_49%,rgba(91,140,255,.035)_50%)] bg-[length:100%_4px]" />
              <div className="relative space-y-2.5">
                {visibleLines.map((line, index) => (
                  <motion.div key={`${lineOffset}-${index}`} initial={reduceMotion ? false : { opacity: 0, x: -8 }} animate={{ opacity: 1 - index * 0.055, x: 0 }} className="flex gap-4 font-mono text-[10px] leading-4 sm:text-[11px]">
                    <span className="w-5 shrink-0 select-none text-right text-slate-600">{String(lineOffset + index + 1).padStart(2, "0")}</span>
                    <code className={`truncate ${index === 0 ? "text-blue-300" : line.includes("img") || line.includes("button") || line.includes("input") ? "text-amber-200/80" : "text-slate-400"}`}>{line}</code>
                    {index === 0 && <motion.span layoutId="code-scan-marker" className="ml-auto h-1.5 w-1.5 shrink-0 rounded-full bg-blue-400 shadow-[0_0_10px_#60a5fa]" />}
                  </motion.div>
                ))}
              </div>
              <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-[#080e19] to-transparent" />
              <div className="absolute bottom-5 left-5 right-5 flex items-center gap-3 rounded-lg border border-blue-400/15 bg-blue-400/5 px-3 py-2 backdrop-blur-md">
                <Braces size={13} className="text-blue-400" />
                <AnimatePresence mode="wait"><motion.code key={stage} initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }} className="truncate font-mono text-[9px] text-blue-200/70">assert({STAGES[stage].rule.toLowerCase().replaceAll(" / ", ".")} · source.offset)</motion.code></AnimatePresence>
              </div>
            </div>
          </div>

          <div className="flex flex-col p-5 sm:p-7">
            <div className="mb-6 flex items-center justify-between"><div><p className="text-xs font-semibold">Analysis pipeline</p><p className="mt-1 text-[10px] text-muted">Source-aware accessibility checks</p></div><span className="font-mono text-xl font-medium tracking-[-0.05em] text-[var(--accent-bright)]">{progress}%</span></div>
            <div className="space-y-2">
              {STAGES.map((item, index) => {
                const Icon = item.icon;
                const active = index === stage;
                const complete = index < stage;
                return (
                  <motion.div key={item.label} animate={{ opacity: index > stage + 1 ? 0.38 : 1 }} className={`relative flex items-center gap-3 rounded-xl border p-3 transition-colors ${active ? "border-[var(--accent-line)] bg-[var(--accent-soft)]" : "border-transparent"}`}>
                    <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg border ${active ? "border-[var(--accent-line)] text-[var(--accent-bright)]" : complete ? "border-emerald-400/20 bg-emerald-400/10 text-emerald-400" : "border-[var(--border)] text-muted"}`}>
                      {complete ? <Check size={14} /> : <Icon size={14} className={active ? "pulse-dot" : ""} />}
                    </span>
                    <div className="min-w-0"><p className={`text-[11px] font-medium ${active ? "text-[var(--text)]" : "text-soft"}`}>{item.label}</p><p className="mt-0.5 truncate text-[9px] text-muted">{item.detail}</p></div>
                    {active && <motion.span layoutId="stage-active" className="absolute bottom-0 left-12 right-3 h-px bg-[var(--accent-line)]" />}
                  </motion.div>
                );
              })}
            </div>
            <div className="mt-auto pt-6"><div className="h-1 overflow-hidden rounded-full bg-[var(--border)]"><motion.div className="h-full rounded-full bg-gradient-to-r from-[var(--accent)] to-[var(--accent-two)]" animate={{ width: `${progress}%` }} transition={{ duration: 0.55, ease: "easeOut" }} /></div><p className="mt-3 text-center text-[9px] text-muted">No visual guesswork · every finding maps back to source</p></div>
          </div>
        </div>
      </div>
    </main>
  );
}
