"use client";

import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, Check, CheckCircle2, Code2, Sparkles, WandSparkles } from "lucide-react";
import type { AccessibilityIssue, Severity } from "@/lib/accessibility/types";

const SEVERITY_STYLE: Record<Severity, { color: string; bg: string; border: string; label: string }> = {
  critical: { color: "#f7a641", bg: "rgba(245,158,11,.09)", border: "rgba(245,158,11,.22)", label: "Critical" },
  serious: { color: "#f5bd5f", bg: "rgba(245,181,79,.07)", border: "rgba(245,181,79,.18)", label: "Serious" },
  moderate: { color: "#a8b3c7", bg: "rgba(148,163,184,.06)", border: "rgba(148,163,184,.16)", label: "Moderate" },
};

interface IssueCardProps {
  issue: AccessibilityIssue;
  resolved: boolean;
  active: boolean;
  onHover: (issue: AccessibilityIssue | null) => void;
  onResolve: (issue: AccessibilityIssue) => void;
  onSelect: (issue: AccessibilityIssue) => void;
  compact?: boolean;
}

export function IssueCard({ issue, resolved, active, onHover, onResolve, onSelect, compact = false }: IssueCardProps) {
  const severity = SEVERITY_STYLE[issue.severity];
  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      onMouseEnter={() => onHover(issue)}
      onMouseLeave={() => onHover(null)}
      onFocus={() => onHover(issue)}
      onBlur={() => onHover(null)}
      onClick={() => onSelect(issue)}
      className={`group relative overflow-hidden rounded-xl border p-4 transition-colors ${active ? "border-[var(--accent-line)] bg-[var(--accent-soft)]" : resolved ? "border-emerald-400/15 bg-emerald-400/[.025]" : "border-[var(--border)] bg-[var(--panel)] hover:border-[var(--border-strong)]"}`}
    >
      {active && <motion.span layoutId="active-issue-edge" className="absolute inset-y-4 left-0 w-0.5 rounded-full bg-[var(--accent)]" />}
      <div className="mb-3 flex items-center gap-2">
        <span className="rounded-md border px-2 py-1 text-[8px] font-bold uppercase tracking-[0.13em]" style={{ color: resolved ? "#34d399" : severity.color, background: resolved ? "rgba(52,211,153,.08)" : severity.bg, borderColor: resolved ? "rgba(52,211,153,.2)" : severity.border }}>
          {resolved ? <span className="flex items-center gap-1"><Check size={9} /> Resolved</span> : severity.label}
        </span>
        <span className="text-[9px] font-medium text-muted">WCAG {issue.wcag}</span>
        <span className="ml-auto flex items-center gap-1 font-mono text-[9px] text-muted"><Code2 size={10} /> L{issue.line}</span>
      </div>
      <h3 className="text-[13px] font-semibold leading-5 tracking-[-0.015em] text-soft">{issue.title}</h3>
      {!compact && <p className="mt-1.5 text-[10px] leading-[1.6] text-muted">{issue.description}</p>}
      {issue.context && !compact && <p className="mt-2 truncate font-mono text-[8px] text-[var(--faint)]" title={issue.context}>{issue.context}</p>}

      <div className={`code-window relative mt-3 overflow-hidden rounded-lg border ${resolved ? "code-fixed" : "code-broken"}`}>
        <div className="flex items-center justify-between border-b border-white/[.06] px-3 py-1.5 text-[8px] font-medium uppercase tracking-[0.12em] text-slate-500"><span>{resolved ? "AI-resolved source" : "Offending source"}</span><span>{issue.rule}</span></div>
        <AnimatePresence mode="wait" initial={false}>
          <motion.pre key={resolved ? "fixed" : "broken"} initial={{ opacity: 0, x: resolved ? 8 : -8 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.2 }} className="custom-scroll max-h-[76px] overflow-auto whitespace-pre-wrap break-all px-3 py-2.5 font-mono text-[9px] leading-[1.6] text-slate-400">
            {resolved ? issue.fixedSnippet : issue.snippet}
          </motion.pre>
        </AnimatePresence>
      </div>

      <div className="mt-3 flex items-center gap-2">
        <button
          onClick={(event) => { event.stopPropagation(); onResolve(issue); }}
          className={resolved ? "soft-button flex flex-1 items-center justify-center gap-2 rounded-lg px-3 py-2.5 text-[10px] font-semibold text-emerald-400" : "ai-button flex flex-1 items-center justify-center gap-2 rounded-lg px-3 py-2.5 text-[10px] font-semibold"}
        >
          {resolved ? <><CheckCircle2 size={13} /> View AI resolution <ArrowUpRight size={12} /></> : <><Sparkles size={13} /> Auto-Resolve with AI <WandSparkles size={12} /></>}
        </button>
      </div>
    </motion.article>
  );
}
