export type ScanMode = "demo" | "url" | "code";
export type Severity = "critical" | "serious" | "moderate";
export type ReportLanguage = "en" | "hi";

export type RuleId =
  | "image-alt"
  | "button-name"
  | "link-name"
  | "label"
  | "color-contrast"
  | "heading-order"
  | "html-lang"
  | "tabindex"
  | "focus-visible"
  | "viewport-zoom"
  | "document-title";

export interface SourceEdit {
  start: number;
  end: number;
  replacement: string;
}

export interface AccessibilityIssue {
  id: string;
  rule: RuleId;
  title: string;
  severity: Severity;
  wcag: string;
  wcagTitle: string;
  description: string;
  selector: string;
  snippet: string;
  fixedSnippet: string;
  explanationEn: string;
  explanationHi: string;
  fixLabel: string;
  line: number;
  start: number;
  end: number;
  edits: SourceEdit[];
  context?: string;
}

export interface ScanRecord {
  id: string;
  target: string;
  mode: ScanMode;
  title: string;
  source: string;
  issues: AccessibilityIssue[];
  initialScore: number;
  score: number;
  resolvedIds: string[];
  durationMs: number;
  notice: string | null;
  isSimulated: boolean;
  passedRules: RuleId[];
  createdAt: string;
  updatedAt: string;
}

export interface ScanRequest {
  mode: ScanMode;
  url?: string;
  code?: string;
  demoId?: string;
}

export interface ScanResponse {
  scan: ScanRecord;
}

export interface DemoWorld {
  id: string;
  name: string;
  category: string;
  url: string;
  description: string;
  detail: string;
  accent: string;
  surface: string;
  source: string;
}

export const SEVERITY_WEIGHT: Record<Severity, number> = {
  critical: 12,
  serious: 7,
  moderate: 4,
};

export function calculateScore(
  issues: AccessibilityIssue[],
  resolvedIds: string[] = [],
) {
  const resolved = new Set(resolvedIds);
  const penalty = issues.reduce(
    (total, issue) =>
      total + (resolved.has(issue.id) ? 0 : SEVERITY_WEIGHT[issue.severity]),
    0,
  );
  return Math.max(0, Math.min(100, 100 - penalty));
}
