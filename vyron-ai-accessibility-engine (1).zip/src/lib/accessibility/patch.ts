import { createTwoFilesPatch } from "diff";
import type { AccessibilityIssue, SourceEdit } from "@/lib/accessibility/types";

export function applyResolvedFixes(
  source: string,
  issues: AccessibilityIssue[],
  resolvedIds: string[],
) {
  const resolved = new Set(resolvedIds);
  const uniqueEdits = new Map<string, SourceEdit>();
  for (const issue of issues) {
    if (!resolved.has(issue.id)) continue;
    for (const edit of issue.edits) {
      uniqueEdits.set(`${edit.start}:${edit.end}:${edit.replacement}`, edit);
    }
  }
  const edits = Array.from(uniqueEdits.values()).sort(
    (a, b) => b.start - a.start || b.end - a.end,
  );
  let output = source;
  let nextRegionStart = source.length + 1;
  for (const edit of edits) {
    if (edit.end > nextRegionStart) continue;
    output = `${output.slice(0, edit.start)}${edit.replacement}${output.slice(edit.end)}`;
    nextRegionStart = edit.start;
  }
  return output;
}

export function createUnifiedPatch(
  source: string,
  issues: AccessibilityIssue[],
  resolvedIds: string[],
) {
  const fixedSource = applyResolvedFixes(source, issues, resolvedIds);
  return createTwoFilesPatch(
    "original.html",
    "vyron-fixed.html",
    source,
    fixedSource,
    "Original source",
    "VYRON accessible source",
    { context: 4 },
  );
}

export function resolvedFixCount(
  issues: AccessibilityIssue[],
  resolvedIds: string[],
) {
  const resolved = new Set(resolvedIds);
  return issues.filter((issue) => resolved.has(issue.id)).length;
}
