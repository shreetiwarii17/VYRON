import type { jsPDF } from "jspdf";
import type { ReportLanguage, ScanRecord } from "@/lib/accessibility/types";
import { ISSUE_TITLE_HI, REPORT_COPY, reportPriority, reportSummary } from "@/lib/accessibility/reporting";
import { safeFilename } from "@/lib/client-utils";

const PAGE_WIDTH = 210;
const PAGE_HEIGHT = 297;
const MARGIN = 18;
const CONTENT_WIDTH = PAGE_WIDTH - MARGIN * 2;
const BOTTOM = 282;

function addEnglish(doc: jsPDF, text: string, y: number, options?: { size?: number; color?: [number, number, number]; font?: "helvetica" | "courier"; style?: "normal" | "bold"; width?: number; lineHeight?: number }) {
  const size = options?.size ?? 9;
  const width = options?.width ?? CONTENT_WIDTH;
  const lineHeight = options?.lineHeight ?? size * 0.48;
  doc.setFont(options?.font ?? "helvetica", options?.style ?? "normal");
  doc.setFontSize(size);
  doc.setTextColor(...(options?.color ?? [51, 65, 85]));
  const lines = doc.splitTextToSize(text, width) as string[];
  for (const line of lines) {
    if (y > BOTTOM) {
      doc.addPage();
      y = 22;
    }
    doc.text(line, MARGIN, y);
    y += lineHeight;
  }
  return y;
}

function makeHindiCanvas(text: string, bold = false) {
  const canvas = document.createElement("canvas");
  const width = 1200;
  const fontSize = 30;
  const lineHeight = 47;
  canvas.width = width;
  const measure = canvas.getContext("2d");
  if (!measure) throw new Error("Canvas is unavailable for Hindi PDF rendering.");
  const font = `${bold ? 600 : 400} ${fontSize}px "Noto Sans Devanagari", "Nirmala UI", Mangal, sans-serif`;
  measure.font = font;
  const paragraphs = text.split("\n");
  const lines: string[] = [];
  for (const paragraph of paragraphs) {
    let current = "";
    for (const word of paragraph.split(/\s+/)) {
      const candidate = current ? `${current} ${word}` : word;
      if (current && measure.measureText(candidate).width > width - 30) {
        lines.push(current);
        current = word;
      } else current = candidate;
    }
    lines.push(current);
  }
  canvas.height = Math.max(lineHeight + 12, lines.length * lineHeight + 12);
  const context = canvas.getContext("2d");
  if (!context) throw new Error("Canvas is unavailable for Hindi PDF rendering.");
  context.font = font;
  context.fillStyle = "#334155";
  context.textBaseline = "top";
  lines.forEach((line, index) => context.fillText(line, 8, 6 + index * lineHeight));
  return canvas;
}

function addHindi(doc: jsPDF, text: string, y: number, options?: { bold?: boolean; width?: number }) {
  const canvas = makeHindiCanvas(text, options?.bold);
  const width = options?.width ?? CONTENT_WIDTH;
  const height = (canvas.height / canvas.width) * width;
  if (y + height > BOTTOM) {
    doc.addPage();
    y = 20;
  }
  doc.addImage(canvas.toDataURL("image/png"), "PNG", MARGIN, y, width, height, undefined, "FAST");
  return y + height + 2;
}

function addLocalized(doc: jsPDF, text: string, y: number, language: ReportLanguage, options?: { size?: number; bold?: boolean; color?: [number, number, number] }) {
  return language === "hi"
    ? addHindi(doc, text, y, { bold: options?.bold })
    : addEnglish(doc, text, y, { size: options?.size ?? (options?.bold ? 12 : 9), style: options?.bold ? "bold" : "normal", color: options?.color });
}

function addRule(doc: jsPDF, y: number) {
  if (y > BOTTOM) {
    doc.addPage();
    return 22;
  }
  doc.setDrawColor(226, 232, 240);
  doc.line(MARGIN, y, PAGE_WIDTH - MARGIN, y);
  return y + 7;
}

export async function downloadScanReport(scan: ScanRecord, language: ReportLanguage) {
  const { jsPDF: JsPDF } = await import("jspdf");
  const doc = new JsPDF({ orientation: "portrait", unit: "mm", format: "a4", compress: true });
  doc.setProperties({
    title: `VYRON Accessibility Report — ${scan.title}`,
    subject: "Source-level accessibility findings and resolutions",
    author: "VYRON by Team Kritrim",
    creator: "VYRON Accessibility Engine",
  });
  const copy = REPORT_COPY[language];

  doc.setFillColor(11, 17, 32);
  doc.rect(0, 0, PAGE_WIDTH, 45, "F");
  doc.setTextColor(111, 151, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(24);
  doc.text("VYRON", MARGIN, 21);
  doc.setFontSize(7);
  doc.setTextColor(148, 163, 184);
  doc.text("BY TEAM KRITRIM  /  AI ACCESSIBILITY ENGINE", MARGIN, 28);
  doc.setFontSize(8);
  doc.text(`WCAG 2.2  /  ${language === "hi" ? "HINDI REPORT" : "ENGLISH REPORT"}`, PAGE_WIDTH - MARGIN, 21, { align: "right" });
  doc.text(new Date(scan.updatedAt).toLocaleString(language === "hi" ? "hi-IN" : "en-IN"), PAGE_WIDTH - MARGIN, 28, { align: "right" });

  let y = 58;
  y = addLocalized(doc, copy.report, y, language, { bold: true, size: 18, color: [15, 23, 42] });
  y = addEnglish(doc, scan.title, y + 1, { size: 11, style: "bold", color: [51, 65, 85] });
  y = addEnglish(doc, scan.target, y + 1, { size: 7.5, color: [100, 116, 139] }) + 5;

  const cards = [
    { label: "CURRENT SCORE", value: `${scan.score}/100`, color: scan.score >= 85 ? [5, 150, 105] : scan.score >= 60 ? [49, 100, 232] : [197, 116, 0] },
    { label: "RESOLVED", value: `${scan.resolvedIds.length}/${scan.issues.length}`, color: [5, 150, 105] },
    { label: "INITIAL SCORE", value: `${scan.initialScore}/100`, color: [100, 116, 139] },
  ];
  const gap = 4;
  const cardWidth = (CONTENT_WIDTH - gap * 2) / 3;
  cards.forEach((card, index) => {
    const x = MARGIN + index * (cardWidth + gap);
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(x, y, cardWidth, 24, 2, 2, "FD");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(6.5);
    doc.setTextColor(100, 116, 139);
    doc.text(card.label, x + 4, y + 7);
    doc.setFontSize(15);
    doc.setTextColor(...(card.color as [number, number, number]));
    doc.text(card.value, x + 4, y + 17);
  });
  y += 33;

  y = addLocalized(doc, copy.summary, y, language, { bold: true, size: 12, color: [15, 23, 42] });
  y = addLocalized(doc, reportSummary(scan, language), y + 2, language, { size: 9 }) + 5;
  y = addLocalized(doc, copy.priority, y, language, { bold: true, size: 11, color: [15, 23, 42] });
  y = addLocalized(doc, reportPriority(scan, language), y + 2, language, { size: 9 }) + 4;
  if (scan.notice) {
    y = addRule(doc, y);
    y = addEnglish(doc, `RETRIEVAL NOTE: ${scan.notice}`, y, { size: 7.5, color: [180, 110, 20] }) + 4;
  }

  y = addRule(doc, y);
  y = addLocalized(doc, copy.findings, y, language, { bold: true, size: 13, color: [15, 23, 42] }) + 2;

  scan.issues.forEach((issue, index) => {
    if (y > 245) {
      doc.addPage();
      y = 22;
    }
    const resolved = scan.resolvedIds.includes(issue.id);
    const title = language === "hi" ? ISSUE_TITLE_HI[issue.rule] : issue.title;
    y = addLocalized(doc, `${index + 1}. ${title}`, y + 3, language, { bold: true, size: 11, color: [15, 23, 42] });
    y = addEnglish(doc, `${issue.severity.toUpperCase()}  /  WCAG ${issue.wcag}  /  LINE ${issue.line}  /  ${resolved ? "RESOLVED" : "OPEN"}`, y + 1, { size: 6.8, style: "bold", color: resolved ? [5, 150, 105] : [190, 120, 20] }) + 2;
    y = addLocalized(doc, language === "hi" ? issue.explanationHi : issue.explanationEn, y, language, { size: 8.5 }) + 2;
    if (issue.context) y = addEnglish(doc, issue.context, y, { size: 6.8, color: [100, 116, 139] }) + 2;
    y = addEnglish(doc, language === "hi" ? "ORIGINAL / BROKEN SOURCE" : copy.before.toUpperCase(), y, { size: 6.5, style: "bold", color: [185, 80, 80] });
    y = addEnglish(doc, issue.snippet, y + 1, { size: 6.6, font: "courier", color: [90, 65, 70], lineHeight: 3.4 }) + 2;
    y = addEnglish(doc, language === "hi" ? "VYRON / FIXED SOURCE" : copy.after.toUpperCase(), y, { size: 6.5, style: "bold", color: [5, 150, 105] });
    y = addEnglish(doc, issue.fixedSnippet, y + 1, { size: 6.6, font: "courier", color: [35, 90, 75], lineHeight: 3.4 }) + 3;
    y = addRule(doc, y);
  });

  y += 3;
  y = addLocalized(doc, copy.conformance, y, language, { bold: true, size: 10, color: [15, 23, 42] });
  addLocalized(doc, copy.conformanceText, y + 2, language, { size: 8 });

  const pages = doc.getNumberOfPages();
  for (let page = 1; page <= pages; page += 1) {
    doc.setPage(page);
    doc.setDrawColor(226, 232, 240);
    doc.line(MARGIN, 288, PAGE_WIDTH - MARGIN, 288);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(6.5);
    doc.setTextColor(120, 135, 155);
    doc.text("VYRON  /  AUTOMATED SOURCE AUDIT  /  MANUAL VERIFICATION REQUIRED", MARGIN, 293);
    doc.text(`${page} / ${pages}`, PAGE_WIDTH - MARGIN, 293, { align: "right" });
  }

  doc.save(`vyron-${safeFilename(scan.title)}-${language}-report.pdf`);
}
