import type {
  AccessibilityIssue,
  RuleId,
  Severity,
  SourceEdit,
} from "@/lib/accessibility/types";
import { calculateScore } from "@/lib/accessibility/types";

export const RULE_CATALOG: Array<{
  id: RuleId;
  label: string;
  wcag: string;
}> = [
  { id: "image-alt", label: "Text alternatives", wcag: "1.1.1" },
  { id: "button-name", label: "Button accessible names", wcag: "4.1.2" },
  { id: "link-name", label: "Link purpose", wcag: "2.4.4" },
  { id: "label", label: "Form labels", wcag: "3.3.2" },
  { id: "color-contrast", label: "Color contrast", wcag: "1.4.3" },
  { id: "heading-order", label: "Heading hierarchy", wcag: "1.3.1" },
  { id: "html-lang", label: "Document language", wcag: "3.1.1" },
  { id: "tabindex", label: "Logical tab order", wcag: "2.4.3" },
  { id: "focus-visible", label: "Visible keyboard focus", wcag: "2.4.7" },
  { id: "viewport-zoom", label: "Browser zoom", wcag: "1.4.4" },
  { id: "document-title", label: "Page title", wcag: "2.4.2" },
];

interface RuleCopy {
  title: string;
  severity: Severity;
  wcag: string;
  wcagTitle: string;
  description: string;
  explanationEn: string;
  explanationHi: string;
  fixLabel: string;
}

const COPY: Record<RuleId, RuleCopy> = {
  "image-alt": {
    title: "Image has no text alternative",
    severity: "serious",
    wcag: "1.1.1",
    wcagTitle: "Non-text Content · Level A",
    description: "A screen reader announces the file path instead of the image’s purpose.",
    explanationEn: "Screen reader users cannot perceive this image, so alternative text is needed to communicate its meaning. Adding a concise alt attribute exposes the visual content and satisfies WCAG 1.1.1.",
    explanationHi: "स्क्रीन रीडर उपयोगकर्ता इस चित्र को देख नहीं सकते, इसलिए उसका अर्थ बताने के लिए वैकल्पिक पाठ ज़रूरी है। सटीक alt जोड़ने से चित्र की जानकारी उपलब्ध होती है और WCAG 1.1.1 का पालन होता है।",
    fixLabel: "Generate meaningful alt text",
  },
  "button-name": {
    title: "Button has no accessible name",
    severity: "critical",
    wcag: "4.1.2",
    wcagTitle: "Name, Role, Value · Level A",
    description: "Assistive technology encounters an unnamed button with no clear action.",
    explanationEn: "An icon or visually hidden label does not give this button a dependable accessible name. The injected aria-label tells screen reader users exactly what activating the control will do.",
    explanationHi: "आइकन या छिपा हुआ लेबल इस बटन को भरोसेमंद accessible name नहीं देता। जोड़ा गया aria-label स्क्रीन रीडर उपयोगकर्ता को बताता है कि बटन दबाने पर क्या होगा।",
    fixLabel: "Inject an accessible name",
  },
  "link-name": {
    title: "Link has no discernible text",
    severity: "critical",
    wcag: "2.4.4",
    wcagTitle: "Link Purpose · Level A",
    description: "The destination cannot be understood when the link is announced out of context.",
    explanationEn: "A decorative arrow alone gives screen reader users no information about this link’s destination. Naming the link makes its purpose clear in both page flow and a links list.",
    explanationHi: "केवल सजावटी तीर स्क्रीन रीडर उपयोगकर्ता को लिंक का गंतव्य नहीं बताता। लिंक को नाम देने से उसका उद्देश्य पेज और लिंक सूची दोनों में स्पष्ट हो जाता है।",
    fixLabel: "Name the link destination",
  },
  label: {
    title: "Form field is missing a label",
    severity: "critical",
    wcag: "3.3.2",
    wcagTitle: "Labels or Instructions · Level A",
    description: "Placeholder text is not a persistent programmatic label for this field.",
    explanationEn: "A placeholder disappears during typing and is not consistently announced as a field name. This accessible label keeps the input’s purpose available to assistive technology at all times.",
    explanationHi: "Placeholder टाइप करते समय गायब हो जाता है और हमेशा फ़ील्ड का नाम नहीं बताया जाता। यह accessible label इनपुट का उद्देश्य हर समय स्क्रीन रीडर तक पहुँचाता है।",
    fixLabel: "Attach a programmatic label",
  },
  "color-contrast": {
    title: "Text contrast is below the minimum",
    severity: "serious",
    wcag: "1.4.3",
    wcagTitle: "Contrast (Minimum) · Level AA",
    description: "Low luminance separation makes this content difficult to read in bright light or with low vision.",
    explanationEn: "The measured foreground-to-background contrast falls below the WCAG threshold for this text size. The revised color preserves the background while increasing luminance separation to a readable ratio.",
    explanationHi: "मापा गया टेक्स्ट और बैकग्राउंड कंट्रास्ट इस आकार के लिए WCAG सीमा से कम है। नया रंग बैकग्राउंड बनाए रखते हुए पढ़ने योग्य कंट्रास्ट अनुपात बढ़ाता है।",
    fixLabel: "Tune color to a passing ratio",
  },
  "heading-order": {
    title: "Heading level skips a rank",
    severity: "moderate",
    wcag: "1.3.1",
    wcagTitle: "Info and Relationships · Level A",
    description: "The document outline jumps a level, obscuring the relationship between sections.",
    explanationEn: "Heading levels communicate the structure of a page, not just its visual size. Correcting this skipped rank creates a coherent outline for screen reader heading navigation.",
    explanationHi: "Heading levels पेज की संरचना बताते हैं, केवल दिखने का आकार नहीं। छूटे हुए स्तर को ठीक करने से स्क्रीन रीडर नेविगेशन के लिए सही और सुसंगत रूपरेखा बनती है।",
    fixLabel: "Repair the document outline",
  },
  "html-lang": {
    title: "Document language is not declared",
    severity: "serious",
    wcag: "3.1.1",
    wcagTitle: "Language of Page · Level A",
    description: "Speech engines may select the wrong pronunciation rules for the page.",
    explanationEn: "Screen readers rely on the document language to choose correct pronunciation and voice rules. Declaring English on the html element prevents mispronounced content and improves comprehension.",
    explanationHi: "स्क्रीन रीडर सही उच्चारण और आवाज़ चुनने के लिए पेज की भाषा पर निर्भर करता है। html तत्व पर English घोषित करने से सामग्री का गलत उच्चारण रुकता है और समझ बेहतर होती है।",
    fixLabel: "Declare the page language",
  },
  tabindex: {
    title: "Positive tabindex disrupts tab order",
    severity: "serious",
    wcag: "2.4.3",
    wcagTitle: "Focus Order · Level A",
    description: "A positive tabindex pulls focus out of the natural document sequence.",
    explanationEn: "Positive tabindex values override the predictable order created by the document structure. Setting this value to zero keeps the control keyboard accessible without displacing other content.",
    explanationHi: "Positive tabindex दस्तावेज़ के स्वाभाविक क्रम को बदल देता है और कीबोर्ड उपयोगकर्ता को भ्रमित करता है। इसे शून्य करने से कंट्रोल उपलब्ध रहता है और focus order सही रहता है।",
    fixLabel: "Restore natural focus order",
  },
  "focus-visible": {
    title: "Keyboard focus indicator is removed",
    severity: "serious",
    wcag: "2.4.7",
    wcagTitle: "Focus Visible · Level AA",
    description: "Keyboard users cannot see where focus moves on this interactive element.",
    explanationEn: "Removing the outline leaves keyboard users without a visible indication of the current control. A high-visibility outline and offset restore clear focus without changing the component layout.",
    explanationHi: "Outline हटाने से कीबोर्ड उपयोगकर्ता को current control का कोई दृश्य संकेत नहीं मिलता। स्पष्ट outline और offset लेआउट बदले बिना focus को फिर से दिखाई देने योग्य बनाते हैं।",
    fixLabel: "Restore a visible focus ring",
  },
  "viewport-zoom": {
    title: "Page prevents pinch zoom",
    severity: "serious",
    wcag: "1.4.4",
    wcagTitle: "Resize Text · Level AA",
    description: "Viewport settings stop people with low vision from magnifying the interface.",
    explanationEn: "Disabling user scaling removes an essential magnification method on touch devices. Allowing browser zoom lets readers enlarge content while preserving the responsive layout.",
    explanationHi: "User scaling बंद करने से टच डिवाइस पर ज़रूरी zoom सुविधा हट जाती है। Browser zoom की अनुमति देने से पाठक responsive layout बनाए रखते हुए सामग्री बड़ी कर सकते हैं।",
    fixLabel: "Re-enable browser zoom",
  },
  "document-title": {
    title: "Page has no descriptive title",
    severity: "moderate",
    wcag: "2.4.2",
    wcagTitle: "Page Titled · Level A",
    description: "Browser tabs and screen readers lack a concise way to identify this page.",
    explanationEn: "The page title is often the first announcement when a screen reader enters a new document. A descriptive title helps users identify the page and distinguish it among open tabs.",
    explanationHi: "नए पेज पर आते समय स्क्रीन रीडर अक्सर सबसे पहले उसका title बोलता है। स्पष्ट title उपयोगकर्ता को पेज पहचानने और खुले tabs में अंतर करने में मदद करता है।",
    fixLabel: "Write a descriptive page title",
  },
};

function humanize(value: string) {
  const cleaned = value
    .replace(/\.[a-z0-9]+$/i, "")
    .replace(/[-_]+/g, " ")
    .replace(/\b\d{3,}\b/g, "")
    .replace(/\s+/g, " ")
    .trim();
  if (!cleaned) return "Descriptive image";
  return cleaned.charAt(0).toUpperCase() + cleaned.slice(1);
}

function escapeAttribute(value: string) {
  return value.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");
}

function getAttribute(tag: string, name: string) {
  const expression = new RegExp(`\\b${name}\\s*=\\s*(["'])([\\s\\S]*?)\\1`, "i");
  return expression.exec(tag)?.[2] ?? null;
}

function hasAttribute(tag: string, name: string) {
  // Requiring preceding whitespace avoids treating data-alt as alt, etc.
  return new RegExp(`\\s${name}(?:\\s*=|\\s|/?>)`, "i").test(tag);
}

function insertionOffset(tag: string) {
  return tag.length - (tag.endsWith("/>") ? 2 : 1);
}

function addAttribute(snippet: string, attribute: string) {
  const at = insertionOffset(snippet);
  return `${snippet.slice(0, at)} ${attribute}${snippet.slice(at)}`;
}

function attributeInsertionEdit(
  sourceStart: number,
  snippet: string,
  attribute: string,
): SourceEdit {
  const at = insertionOffset(snippet);
  return {
    start: sourceStart + at,
    end: sourceStart + at,
    replacement: ` ${attribute}`,
  };
}

function textContent(fragment: string) {
  return fragment
    .replace(/<svg\b[^>]*>[\s\S]*?<\/svg>/gi, "")
    .replace(/<([a-z][\w-]*)\b[^>]*aria-hidden\s*=\s*(["'])true\2[^>]*>[\s\S]*?<\/\1>/gi, "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/\s+/g, " ")
    .trim();
}

function lineAt(source: string, offset: number) {
  return source.slice(0, offset).split("\n").length;
}

function makeIssue(
  source: string,
  rule: RuleId,
  index: number,
  details: {
    start: number;
    end: number;
    snippet: string;
    fixedSnippet: string;
    selector: string;
    edits: SourceEdit[];
    context?: string;
    description?: string;
    explanationEn?: string;
    explanationHi?: string;
  },
): AccessibilityIssue {
  const copy = COPY[rule];
  return {
    id: `${rule}-${index}`,
    rule,
    title: copy.title,
    severity: copy.severity,
    wcag: copy.wcag,
    wcagTitle: copy.wcagTitle,
    description: details.description ?? copy.description,
    explanationEn: details.explanationEn ?? copy.explanationEn,
    explanationHi: details.explanationHi ?? copy.explanationHi,
    fixLabel: copy.fixLabel,
    selector: details.selector,
    snippet: details.snippet,
    fixedSnippet: details.fixedSnippet,
    line: lineAt(source, details.start),
    start: details.start,
    end: details.end,
    edits: details.edits,
    context: details.context,
  };
}

interface RGB {
  r: number;
  g: number;
  b: number;
}

function parseColor(value: string): RGB | null {
  const color = value.trim().toLowerCase();
  const named: Record<string, string> = {
    white: "#ffffff",
    black: "#000000",
    red: "#ff0000",
    gray: "#808080",
    grey: "#808080",
  };
  const normalized = named[color] ?? color;
  if (/^#[0-9a-f]{3}$/i.test(normalized)) {
    return {
      r: parseInt(normalized[1] + normalized[1], 16),
      g: parseInt(normalized[2] + normalized[2], 16),
      b: parseInt(normalized[3] + normalized[3], 16),
    };
  }
  if (/^#[0-9a-f]{6}$/i.test(normalized)) {
    return {
      r: parseInt(normalized.slice(1, 3), 16),
      g: parseInt(normalized.slice(3, 5), 16),
      b: parseInt(normalized.slice(5, 7), 16),
    };
  }
  const rgb = normalized.match(/^rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)/);
  if (rgb) return { r: Number(rgb[1]), g: Number(rgb[2]), b: Number(rgb[3]) };
  return null;
}

function luminance(color: RGB) {
  const channels = [color.r, color.g, color.b].map((channel) => {
    const value = channel / 255;
    return value <= 0.03928 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
  });
  return channels[0] * 0.2126 + channels[1] * 0.7152 + channels[2] * 0.0722;
}

export function contrastRatio(foreground: string, background: string) {
  const first = parseColor(foreground);
  const second = parseColor(background);
  if (!first || !second) return null;
  const light = Math.max(luminance(first), luminance(second));
  const dark = Math.min(luminance(first), luminance(second));
  return (light + 0.05) / (dark + 0.05);
}

function accessibleColor(background: string, threshold: number) {
  const backgroundColor = parseColor(background);
  if (!backgroundColor) return null;
  const candidates =
    luminance(backgroundColor) > 0.35
      ? ["#475569", "#334155", "#1f2937", "#111827", "#000000"]
      : ["#cbd5e1", "#e2e8f0", "#f8fafc", "#ffffff"];
  return (
    candidates.find((candidate) => {
      const ratio = contrastRatio(candidate, background);
      return ratio !== null && ratio >= threshold;
    }) ?? candidates[candidates.length - 1]
  );
}

function styleValueStart(tag: string, tagStart: number, match: RegExpExecArray) {
  const equals = match[0].indexOf("=");
  const quote = match[0].indexOf(match[1], equals);
  return tagStart + (match.index ?? 0) + quote + 1;
}

export function auditSource(source: string, pageTitle = "Accessible web page") {
  const issues: AccessibilityIssue[] = [];
  const counters = new Map<RuleId, number>();
  const nextIndex = (rule: RuleId) => {
    const value = counters.get(rule) ?? 0;
    counters.set(rule, value + 1);
    return value;
  };
  const push = (
    rule: RuleId,
    details: Parameters<typeof makeIssue>[3],
  ) => issues.push(makeIssue(source, rule, nextIndex(rule), details));

  for (const match of source.matchAll(/<img\b[^>]*>/gi)) {
    const snippet = match[0];
    const start = match.index ?? 0;
    if (hasAttribute(snippet, "alt")) continue;
    const src = getAttribute(snippet, "src") ?? "content image";
    const filename = src.split("/").pop()?.split("?")[0] ?? "content image";
    const alt = humanize(filename);
    const attribute = `alt="${escapeAttribute(alt)}"`;
    push("image-alt", {
      start,
      end: start + snippet.length,
      snippet,
      fixedSnippet: addAttribute(snippet, attribute),
      selector: "img",
      edits: [attributeInsertionEdit(start, snippet, attribute)],
      context: `Suggested from the image asset “${filename}”. Review for editorial accuracy.`,
    });
  }

  for (const match of source.matchAll(/<button\b([^>]*)>[\s\S]*?<\/button>/gi)) {
    const fragment = match[0];
    const start = match.index ?? 0;
    const opening = fragment.match(/^<button\b[^>]*>/i)?.[0];
    if (!opening) continue;
    if (
      textContent(fragment) ||
      hasAttribute(opening, "aria-label") ||
      hasAttribute(opening, "aria-labelledby") ||
      hasAttribute(opening, "title")
    )
      continue;
    const rawText = fragment.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
    const label =
      getAttribute(opening, "data-vyron-label") ??
      (rawText ? rawText.slice(0, 64) : null) ??
      humanize(getAttribute(opening, "id") ?? getAttribute(opening, "class") ?? "Perform action");
    const attribute = `aria-label="${escapeAttribute(label)}"`;
    push("button-name", {
      start,
      end: start + fragment.length,
      snippet: fragment,
      fixedSnippet: fragment.replace(opening, addAttribute(opening, attribute)),
      selector: "button",
      edits: [attributeInsertionEdit(start, opening, attribute)],
      context: "Accessible name inferred from the control’s visual content and data attributes.",
    });
  }

  for (const match of source.matchAll(/<a\b([^>]*)>[\s\S]*?<\/a>/gi)) {
    const fragment = match[0];
    const start = match.index ?? 0;
    const opening = fragment.match(/^<a\b[^>]*>/i)?.[0];
    if (!opening) continue;
    if (
      textContent(fragment) ||
      hasAttribute(opening, "aria-label") ||
      hasAttribute(opening, "aria-labelledby") ||
      hasAttribute(opening, "title")
    )
      continue;
    const href = getAttribute(opening, "href") ?? "destination";
    const label = humanize(href.split("/").filter(Boolean).pop() ?? "Open destination");
    const attribute = `aria-label="${escapeAttribute(label)}"`;
    push("link-name", {
      start,
      end: start + fragment.length,
      snippet: fragment,
      fixedSnippet: fragment.replace(opening, addAttribute(opening, attribute)),
      selector: "a",
      edits: [attributeInsertionEdit(start, opening, attribute)],
    });
  }

  for (const match of source.matchAll(/<input\b[^>]*>/gi)) {
    const snippet = match[0];
    const start = match.index ?? 0;
    const type = (getAttribute(snippet, "type") ?? "text").toLowerCase();
    if (["hidden", "submit", "button", "reset", "image"].includes(type)) continue;
    const id = getAttribute(snippet, "id");
    const hasExplicitLabel = id
      ? new RegExp(`<label\\b[^>]*for\\s*=\\s*(["'])${id.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\1`, "i").test(source)
      : false;
    if (
      hasExplicitLabel ||
      hasAttribute(snippet, "aria-label") ||
      hasAttribute(snippet, "aria-labelledby")
    )
      continue;
    const label = humanize(
      getAttribute(snippet, "name") ?? getAttribute(snippet, "placeholder") ?? id ?? "Input field",
    );
    const attribute = `aria-label="${escapeAttribute(label)}"`;
    push("label", {
      start,
      end: start + snippet.length,
      snippet,
      fixedSnippet: addAttribute(snippet, attribute),
      selector: "input",
      edits: [attributeInsertionEdit(start, snippet, attribute)],
      context: "A persistent aria-label is used because no associated visible label was found.",
    });
  }

  const openingTags = Array.from(source.matchAll(/<([a-z][\w-]*)\b[^>]*>/gi));
  for (const match of openingTags) {
    const snippet = match[0];
    const start = match.index ?? 0;
    const tagName = match[1].toLowerCase();
    if (["script", "style", "head", "meta", "link", "title"].includes(tagName)) continue;
    const styleMatch = /\bstyle\s*=\s*(["'])([\s\S]*?)\1/i.exec(snippet);
    if (!styleMatch) continue;
    const style = styleMatch[2];
    const valueStart = styleValueStart(snippet, start, styleMatch);

    const focusMatch = /outline\s*:\s*(?:none|0)(?:\s*;)?/i.exec(style);
    if (focusMatch) {
      const editStart = valueStart + (focusMatch.index ?? 0);
      const replacement = "outline:2px solid currentColor;outline-offset:3px;";
      const fixedStyle = style.replace(focusMatch[0], replacement);
      push("focus-visible", {
        start,
        end: start + snippet.length,
        snippet,
        fixedSnippet: snippet.replace(style, fixedStyle),
        selector: tagName,
        edits: [{ start: editStart, end: editStart + focusMatch[0].length, replacement }],
      });
    }

    const foregroundMatch = /(?:^|;)\s*color\s*:\s*(#[0-9a-f]{3,6}|rgba?\([^)]*\)|white|black|red|gray|grey)/i.exec(style);
    const backgroundMatch = /background(?:-color)?\s*:\s*(#[0-9a-f]{3,6}|rgba?\([^)]*\)|white|black|red|gray|grey)/i.exec(style);
    if (!foregroundMatch || !backgroundMatch) continue;
    const foreground = foregroundMatch[1];
    const background = backgroundMatch[1];
    const ratio = contrastRatio(foreground, background);
    if (ratio === null) continue;
    const fontSize = Number(/font-size\s*:\s*([\d.]+)px/i.exec(style)?.[1] ?? 0);
    const bold = /font-weight\s*:\s*(?:bold|[6-9]00)/i.test(style);
    const largeText = fontSize >= 24 || (bold && fontSize >= 18.66);
    const threshold = largeText ? 3 : 4.5;
    if (ratio >= threshold) continue;
    const fixedColor = accessibleColor(background, threshold);
    if (!fixedColor) continue;
    const colorValueRelative = (foregroundMatch.index ?? 0) + foregroundMatch[0].lastIndexOf(foreground);
    const editStart = valueStart + colorValueRelative;
    const fixedStyle = `${style.slice(0, colorValueRelative)}${fixedColor}${style.slice(colorValueRelative + foreground.length)}`;
    const fixedRatio = contrastRatio(fixedColor, background);
    push("color-contrast", {
      start,
      end: start + snippet.length,
      snippet,
      fixedSnippet: snippet.replace(style, fixedStyle),
      selector: tagName,
      edits: [{ start: editStart, end: editStart + foreground.length, replacement: fixedColor }],
      context: `Measured ${ratio.toFixed(2)}:1 → ${fixedRatio?.toFixed(2) ?? "passing"}:1 · ${threshold}:1 required`,
      description: `Measured contrast is ${ratio.toFixed(2)}:1; this text requires at least ${threshold}:1.`,
    });
  }

  const headings = Array.from(source.matchAll(/<h([1-6])\b[^>]*>[\s\S]*?<\/h\1>/gi));
  let previousLevel = 0;
  for (const match of headings) {
    const level = Number(match[1]);
    if (previousLevel && level > previousLevel + 1) {
      const fragment = match[0];
      const start = match.index ?? 0;
      const targetLevel = previousLevel + 1;
      const closeRelative = fragment.search(/<\/h[1-6]\s*>/i);
      const fixedSnippet = fragment
        .replace(new RegExp(`^<h${level}`, "i"), `<h${targetLevel}`)
        .replace(new RegExp(`<\\/h${level}\\s*>`, "i"), `</h${targetLevel}>`);
      const edits: SourceEdit[] = [
        { start: start + 1, end: start + 3, replacement: `h${targetLevel}` },
      ];
      if (closeRelative >= 0) {
        edits.push({
          start: start + closeRelative + 2,
          end: start + closeRelative + 4,
          replacement: `h${targetLevel}`,
        });
      }
      push("heading-order", {
        start,
        end: start + fragment.length,
        snippet: fragment,
        fixedSnippet,
        selector: `h${level}`,
        edits,
        context: `h${previousLevel} → h${level} becomes h${previousLevel} → h${targetLevel}; visual styling remains unchanged.`,
      });
    }
    previousLevel = previousLevel && level > previousLevel + 1 ? previousLevel + 1 : level;
  }

  const htmlMatch = /<html\b[^>]*>/i.exec(source);
  if (htmlMatch && !hasAttribute(htmlMatch[0], "lang")) {
    const start = htmlMatch.index ?? 0;
    const attribute = 'lang="en"';
    push("html-lang", {
      start,
      end: start + htmlMatch[0].length,
      snippet: htmlMatch[0],
      fixedSnippet: addAttribute(htmlMatch[0], attribute),
      selector: "html",
      edits: [attributeInsertionEdit(start, htmlMatch[0], attribute)],
      context: "Defaulting to English; change lang to the document’s primary language if different.",
    });
  }

  for (const match of source.matchAll(/<([a-z][\w-]*)\b[^>]*tabindex\s*=\s*(["'])([1-9]\d*)\2[^>]*>/gi)) {
    const snippet = match[0];
    const start = match.index ?? 0;
    const attribute = /\btabindex\s*=\s*(["'])[1-9]\d*\1/i.exec(snippet);
    if (!attribute) continue;
    const editStart = start + (attribute.index ?? 0);
    push("tabindex", {
      start,
      end: start + snippet.length,
      snippet,
      fixedSnippet: snippet.replace(attribute[0], 'tabindex="0"'),
      selector: match[1].toLowerCase(),
      edits: [{ start: editStart, end: editStart + attribute[0].length, replacement: 'tabindex="0"' }],
      context: `Changed tabindex="${match[3]}" to tabindex="0".`,
    });
  }

  for (const match of source.matchAll(/<meta\b[^>]*>/gi)) {
    const snippet = match[0];
    const start = match.index ?? 0;
    if ((getAttribute(snippet, "name") ?? "").toLowerCase() !== "viewport") continue;
    const content = getAttribute(snippet, "content") ?? "";
    if (!/user-scalable\s*=\s*(?:no|0)|maximum-scale\s*=\s*1(?:\D|$)/i.test(content)) continue;
    const contentMatch = /\bcontent\s*=\s*(["'])([\s\S]*?)\1/i.exec(snippet);
    if (!contentMatch) continue;
    const valueStart = styleValueStart(snippet, start, contentMatch);
    const replacement = "width=device-width, initial-scale=1";
    push("viewport-zoom", {
      start,
      end: start + snippet.length,
      snippet,
      fixedSnippet: snippet.replace(contentMatch[2], replacement),
      selector: "meta[name=viewport]",
      edits: [{ start: valueStart, end: valueStart + contentMatch[2].length, replacement }],
    });
  }

  const headMatch = /<head\b[^>]*>/i.exec(source);
  const titleMatch = /<title\b[^>]*>[\s\S]*?<\/title>/i.exec(source);
  if (headMatch && (!titleMatch || !textContent(titleMatch[0]))) {
    const start = headMatch.index ?? 0;
    const insertAt = start + headMatch[0].length;
    const safeTitle = escapeAttribute(pageTitle).slice(0, 90);
    const replacement = `\n  <title>${safeTitle}</title>`;
    push("document-title", {
      start,
      end: insertAt,
      snippet: headMatch[0],
      fixedSnippet: `${headMatch[0]}${replacement}`,
      selector: "head",
      edits: [{ start: insertAt, end: insertAt, replacement }],
    });
  }

  issues.sort((a, b) => {
    const rank: Record<Severity, number> = { critical: 0, serious: 1, moderate: 2 };
    return rank[a.severity] - rank[b.severity] || a.start - b.start;
  });
  const failedRules = new Set(issues.map((issue) => issue.rule));
  const passedRules = RULE_CATALOG.map((rule) => rule.id).filter((rule) => !failedRules.has(rule));
  return { issues, score: calculateScore(issues), passedRules };
}

export function createSimulatedSource(rawUrl: string) {
  let hostname = "your-website";
  try {
    hostname = new URL(rawUrl).hostname;
  } catch {
    // The validated request normally prevents this branch.
  }
  const safeHost = hostname.replace(/[&<>"]/g, "");
  return String.raw`<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"><title>${safeHost} · simulated audit</title>
<style>body{margin:0;background:#f6f7fb;color:#172033;font:15px Arial,sans-serif}main{max-width:960px;margin:auto;padding:48px 6%}nav{display:flex;justify-content:space-between;padding:22px 6%;border-bottom:1px solid #dce1ea}h1{font-size:44px;letter-spacing:-2px;margin-bottom:12px}.hero{background:white;border:1px solid #e0e5ed;padding:32px;border-radius:12px}.hero img{width:100%;height:220px;background:#e5e9f1;object-fit:cover}button,input{padding:12px 16px}button{background:#315efb;color:white;border:0}.actions{display:flex;gap:10px;margin-top:20px}.foot{color:#8a94a6}</style></head>
<body><nav><strong>${safeHost}</strong><button data-vyron-label="Open navigation"><span aria-hidden="true">Menu</span></button></nav><main><section class="hero"><p>SIMULATED LOCAL SNAPSHOT</p><h1>Your page, made more usable.</h1><h3>A representative accessibility audit</h3><p style="color:#a3abba;background-color:#ffffff">The live page could not be retrieved, so this local document demonstrates VYRON’s source analysis.</p><img src="website-hero-preview.jpg"><div class="actions"><button>Get started</button><a href="/learn"><span aria-hidden="true">→</span></a></div></section><form><input name="email" placeholder="Work email"><button>Request access</button></form><p class="foot">Replace this simulation by pasting your actual HTML for a source-accurate audit.</p></main></body></html>`;
}
