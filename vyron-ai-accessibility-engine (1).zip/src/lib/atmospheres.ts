export type Atmosphere = "cosmic" | "sunset" | "daylight" | "cyber";

export const ATMOSPHERES: Array<{
  id: Atmosphere;
  name: string;
  shortName: string;
  description: string;
  swatch: string;
}> = [
  {
    id: "sunset",
    name: "Sunset Velvet",
    shortName: "Sunset",
    description: "Warm plum, soft coral, cinematic glow.",
    swatch: "linear-gradient(135deg,#ffb088 0%,#b06ca7 48%,#241329 100%)",
  },
  {
    id: "daylight",
    name: "Daylight Studio",
    shortName: "Daylight",
    description: "Quiet whites, precise blue, editorial clarity.",
    swatch: "linear-gradient(135deg,#ffffff 0%,#dbe7fa 48%,#7697d6 100%)",
  },
  {
    id: "cosmic",
    name: "Cosmic Aura",
    shortName: "Cosmic",
    description: "Deep navy, electric blue, violet ambience.",
    swatch: "linear-gradient(135deg,#7495ff 0%,#6045a8 44%,#0b1120 100%)",
  },
  {
    id: "cyber",
    name: "Cyber Matrix",
    shortName: "Cyber",
    description: "Carbon black, terminal green, digital focus.",
    swatch: "linear-gradient(135deg,#62f2bb 0%,#167a66 45%,#04100c 100%)",
  },
];
