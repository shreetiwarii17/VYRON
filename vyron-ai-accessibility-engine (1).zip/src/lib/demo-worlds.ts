import type { DemoWorld } from "@/lib/accessibility/types";

export const DEMO_WORLDS: DemoWorld[] = [
  {
    id: "aster-row",
    name: "Aster & Row",
    category: "E-commerce",
    url: "https://demo.vyron.local/aster-and-row",
    description: "A quiet fashion storefront with product, cart, and newsletter flows.",
    detail: "7 audit targets · retail UI",
    accent: "#d9a66f",
    surface: "#e9e2d8",
    source: String.raw`<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Aster & Row — Considered goods</title>
  <style>
    *{box-sizing:border-box}body{margin:0;background:#f4f0e9;color:#24211e;font:15px Arial,sans-serif}
    header{display:flex;justify-content:space-between;align-items:center;padding:24px 5%;border-bottom:1px solid #d8d0c4}
    .brand{font-size:20px;letter-spacing:3px}.nav{display:flex;gap:24px}.wrap{max-width:1050px;margin:auto;padding:44px 5%}
    .hero{display:grid;grid-template-columns:1.2fr 1fr;gap:30px;align-items:center}.hero img{width:100%;height:280px;object-fit:cover;background:#d7c6b3}
    h1{font:46px Georgia,serif;line-height:1.05;margin:0 0 16px}h3{font:28px Georgia,serif}.eyebrow{letter-spacing:2px;text-transform:uppercase;font-size:11px}
    button,.button{border:0;background:#292520;color:white;padding:13px 20px;cursor:pointer}.icon{padding:12px;border:1px solid #aaa39a;background:transparent;color:#292520}
    .note{padding:15px 0}.newsletter{display:flex;gap:8px;margin-top:24px}input{padding:13px;border:1px solid #aaa39a;background:transparent;min-width:220px}
    footer{margin-top:44px;border-top:1px solid #d8d0c4;padding-top:20px}@media(max-width:650px){.hero{grid-template-columns:1fr}.nav{display:none}h1{font-size:36px}}
  </style>
</head>
<body>
  <header><div class="brand">ASTER & ROW</div><nav class="nav"><span>New arrivals</span><span>Objects</span><span>Journal</span></nav><button class="icon" data-vyron-label="Open shopping bag"><span aria-hidden="true">Bag · 0</span></button></header>
  <main class="wrap">
    <section class="hero">
      <div><p class="eyebrow">The autumn edit · 2026</p><h1>Objects for a slower everyday.</h1><h3>Natural form. Lasting function.</h3><p class="note" style="color:#a29b91;background-color:#f4f0e9">Small-batch essentials selected for material, maker, and enduring use.</p><button>Explore the collection</button></div>
      <img src="stoneware-collection.jpg">
    </section>
    <section><h3>Notes from the studio</h3><p>Join our monthly letter on craft and considered living.</p><form class="newsletter"><input type="email" name="email" placeholder="Email address"><button>Subscribe</button></form></section>
    <footer><a href="/journal"><span aria-hidden="true">↗</span></a><span style="margin-left:12px">Read our field notes</span></footer>
  </main>
</body>
</html>`,
  },
  {
    id: "northstar-bank",
    name: "Northstar",
    category: "Fintech",
    url: "https://demo.vyron.local/northstar",
    description: "A private banking dashboard with transfers, balances, and support.",
    detail: "Financial UI · dense controls",
    accent: "#69a7ff",
    surface: "#dce8f7",
    source: String.raw`<!doctype html>
<html>
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
  <title>Northstar Private Banking</title>
  <style>
    *{box-sizing:border-box}body{margin:0;background:#edf3fa;color:#15243b;font:14px Arial,sans-serif}header{height:72px;background:#10233f;color:white;display:flex;align-items:center;justify-content:space-between;padding:0 5%}
    .logo{font-weight:bold;font-size:20px;letter-spacing:1px}.shell{max-width:1050px;margin:auto;padding:36px 5%}.grid{display:grid;grid-template-columns:1.5fr 1fr;gap:22px}.card{background:white;border:1px solid #d9e1eb;border-radius:10px;padding:25px;margin-bottom:20px}
    .balance{font-size:40px;font-weight:bold;letter-spacing:-1px}.muted{color:#748199}.transfer{display:grid;gap:12px}input,select{padding:13px;border:1px solid #c8d3e0;background:white}button{background:#2367c9;color:white;border:0;padding:13px;cursor:pointer}.round{border-radius:50%;width:40px;height:40px;padding:0}.activity{display:flex;justify-content:space-between;padding:14px 0;border-bottom:1px solid #e6ebf1}
    @media(max-width:650px){.grid{grid-template-columns:1fr}.balance{font-size:32px}}
  </style>
</head>
<body>
<header><div class="logo">NORTHSTAR / PRIVATE</div><button class="round" data-vyron-label="Open profile">NS</button></header>
<main class="shell"><p class="muted">Tuesday, 14 October</p><h1>Good morning, Maya.</h1><h4>Your financial overview</h4>
<div class="grid"><section><div class="card"><p class="muted">Total balance · INR</p><div class="balance">₹ 24,80,640.00</div><p style="color:#9aa7b7;background-color:#ffffff">+2.4% across your accounts this month</p></div>
<div class="card"><h2>Recent activity</h2><div class="activity"><span>Blue Bottle Coffee</span><strong>− ₹840</strong></div><div class="activity"><span>Salary credit</span><strong>+ ₹1,80,000</strong></div><div class="activity"><span>Utilities</span><strong>− ₹4,290</strong></div></div></section>
<aside><div class="card"><h2>Quick transfer</h2><form class="transfer"><input name="recipient" placeholder="Recipient account"><input name="amount" placeholder="Amount in INR"><button>Review transfer</button></form></div>
<div class="card"><h2>Private support</h2><p>Your client director is available today.</p><a href="/messages"><span aria-hidden="true">→</span></a></div></aside></div></main>
</body></html>`,
  },
  {
    id: "monsoon-atlas",
    name: "Monsoon Atlas",
    category: "Travel",
    url: "https://demo.vyron.local/monsoon-atlas",
    description: "An editorial journey planner spanning stays, routes, and field guides.",
    detail: "Editorial UI · visual content",
    accent: "#f28c6b",
    surface: "#dfe9df",
    source: String.raw`<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Monsoon Atlas — Travel slowly</title>
<style>*{box-sizing:border-box}body{margin:0;background:#f3f3eb;color:#18392f;font:15px Arial,sans-serif}header{padding:22px 5%;display:flex;justify-content:space-between}.wordmark{font:24px Georgia,serif}.hero{position:relative;margin:0 4%;height:360px;background:#b9cbb9;overflow:hidden}.hero img{width:100%;height:100%;object-fit:cover}.caption{position:absolute;left:35px;bottom:28px;color:white;max-width:520px}h1{font:54px Georgia,serif;margin:0 0 10px}.content{max-width:1050px;margin:auto;padding:42px 5%}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.place{background:#e4e8db;padding:20px;border-radius:6px}.place h3{font:24px Georgia,serif}.search{display:flex;gap:8px}input{padding:13px;border:1px solid #99aa99;flex:1}button{background:#18392f;color:white;border:0;padding:13px 20px}.text-link{color:#285d4c}@media(max-width:650px){.cards{grid-template-columns:1fr}.hero{height:420px}h1{font-size:40px}}</style></head>
<body><header><div class="wordmark">Monsoon Atlas</div><div>Destinations &nbsp; Journal &nbsp; About</div></header>
<main><section class="hero"><img src="western-ghats-rain.jpg"><div class="caption"><p>Field guide 08 · Maharashtra</p><h1>Where the rain writes the map.</h1><button style="outline:none">Plan this journey</button></div></section>
<section class="content"><h1>Find your next quiet place</h1><h3>Curated by people who live there.</h3><form class="search"><input name="destination" placeholder="Search a region or landscape"><button data-vyron-label="Search destinations"><span aria-hidden="true">Search</span></button></form>
<p style="color:#9aa496;background-color:#f3f3eb;margin-top:24px">Independent guides, small stays, and routes worth taking slowly.</p>
<div class="cards"><article class="place"><h3>Coorg, Karnataka</h3><p>Coffee estates and cloud forest.</p><a href="/coorg">Explore guide</a></article><article class="place"><h3>Mawphlang, Meghalaya</h3><p>Sacred groves and living root bridges.</p><a href="/mawphlang">Explore guide</a></article><article class="place"><h3>Palampur, Himachal</h3><p>Tea gardens beneath the Dhauladhars.</p><a href="/palampur">Explore guide</a></article></div></section></main></body></html>`,
  },
  {
    id: "kritrim-academy",
    name: "Kritrim Academy",
    category: "Learning",
    url: "https://demo.vyron.local/kritrim-academy",
    description: "A cohort learning space with lessons, progress, and mentor access.",
    detail: "Education UI · keyboard flows",
    accent: "#a78bfa",
    surface: "#e7e2f3",
    source: String.raw`<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Kritrim Academy — Build with intelligence</title>
<style>*{box-sizing:border-box}body{margin:0;background:#f5f3fa;color:#282236;font:14px Arial,sans-serif}nav{height:68px;display:flex;align-items:center;justify-content:space-between;padding:0 5%;border-bottom:1px solid #ddd7e9}.brand{font-weight:bold;font-size:18px}.shell{max-width:1050px;margin:auto;padding:36px 5%}.welcome{display:flex;justify-content:space-between;align-items:center}.avatar{width:48px;height:48px;border-radius:50%;background:#d8cfec}h1{font-size:34px;letter-spacing:-1px;margin:8px 0}.progress{height:8px;background:#ded8e8;border-radius:8px;overflow:hidden}.progress span{display:block;width:64%;height:100%;background:#7154b8}.lessons{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-top:26px}.lesson{background:white;border:1px solid #dfdae8;border-radius:10px;padding:22px}.lesson h3{font-size:19px}.meta{color:#77707f}button{border:0;background:#392c54;color:white;padding:12px 18px}.icon-button{background:transparent;border:1px solid #b9afc8;color:#392c54;padding:10px}@media(max-width:650px){.lessons{grid-template-columns:1fr}}</style></head>
<body><nav><div class="brand">KRITRIM / ACADEMY</div><button class="icon-button" data-vyron-label="Open notifications"><span aria-hidden="true">3 alerts</span></button></nav>
<main class="shell"><section class="welcome"><div><p>Product Engineering · Cohort 04</p><h1>Keep building, Arjun.</h1><h4>Your learning path</h4></div><img class="avatar" src="mentor-riya-profile.png"></section>
<section><div style="display:flex;justify-content:space-between"><span>Course progress</span><strong>64%</strong></div><div class="progress"><span></span></div></section>
<section class="lessons"><article class="lesson" tabindex="3"><p class="meta">Module 06 · 42 min</p><h3>Designing reliable AI systems</h3><p style="color:#aaa3b1;background-color:#ffffff">Evaluation, observability, and useful human feedback.</p><button style="outline:none">Resume lesson</button></article><article class="lesson" tabindex="2"><p class="meta">Live session · Friday</p><h3>Mentor room: systems critique</h3><p>Bring your current architecture for a group review.</p><button>View session details</button></article></section>
<section><h3>Need a human answer?</h3><form><input name="question" placeholder="Ask your mentor"><button>Send question</button></form></section></main></body></html>`,
  },
];

export function getDemoWorld(id: string) {
  return DEMO_WORLDS.find((world) => world.id === id);
}
